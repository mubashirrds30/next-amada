"use strict";
(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 2471:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var lozad__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1790);
/* harmony import */ var lozad__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lozad__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_markdown__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3703);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_markdown__WEBPACK_IMPORTED_MODULE_3__]);
react_markdown__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];
/* eslint-disable @next/next/no-img-element */







const {
  REACT_APP_BASE_URL
} = process.env;

function About({
  info
}) {
  (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(() => {
    const {
      observe
    } = lozad__WEBPACK_IMPORTED_MODULE_0___default()();
    observe();
  }, []); // console.log(info);

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("section", {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
      className: "bs-section",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
        className: "container",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
          className: "sec-cont",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("ul", {
            className: "bs-chain-info typ-img-lg",
            children: info.info.map((ele, i) => {
              return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.Fragment, {
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("li", {
                  className: "item",
                  children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)("div", {
                    className: "bs-img-desc",
                    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)("div", {
                      className: "left-side",
                      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("h2", {
                        className: "title",
                        children: ele.title
                      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
                        className: "img-wrap",
                        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("img", {
                          className: "lozad",
                          alt: ele.title,
                          "data-src": `${REACT_APP_BASE_URL}${ele.image.url}`
                        })
                      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
                        className: "sec-desc",
                        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("p", {
                          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(react_markdown__WEBPACK_IMPORTED_MODULE_3__.default, {
                            className: "rich-text",
                            children: ele.description
                          })
                        })
                      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
                        className: "action-wrap",
                        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__.default, {
                          href: ele.buttonUrl,
                          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("a", {
                            className: "bs-btn btn-default",
                            children: ele.buttonText
                          })
                        })
                      })]
                    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
                      className: "right-side",
                      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
                        className: "img-wrap",
                        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("img", {
                          className: "lozad",
                          alt: ele.title,
                          "data-src": `${REACT_APP_BASE_URL}${ele.image.url}`
                        })
                      })
                    })]
                  })
                }, i)
              });
            })
          })
        })
      })
    })
  });
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (About);
});

/***/ }),

/***/ 8769:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var lozad__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1790);
/* harmony import */ var lozad__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lozad__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var swiper__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4074);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2156);
/* harmony import */ var _VideoModal__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7279);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swiper_react__WEBPACK_IMPORTED_MODULE_4__, swiper__WEBPACK_IMPORTED_MODULE_3__]);
([swiper_react__WEBPACK_IMPORTED_MODULE_4__, swiper__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/* eslint-disable @next/next/no-img-element */














const {
  REACT_APP_BASE_URL
} = process.env;
swiper__WEBPACK_IMPORTED_MODULE_3__.default.use([swiper__WEBPACK_IMPORTED_MODULE_3__.Autoplay, swiper__WEBPACK_IMPORTED_MODULE_3__.Navigation, swiper__WEBPACK_IMPORTED_MODULE_3__.EffectFade, swiper__WEBPACK_IMPORTED_MODULE_3__.Pagination]);

function Banner({
  banner
}) {
  const {
    0: showModal,
    1: setShowModal
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
  const {
    0: videoUrl,
    1: setVideoUrl
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
  const {
    0: state,
    1: setState
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)({
    playing: false,
    played: 0,
    seeking: false
  });

  const playVideo = url => {
    setShowModal(true);

    if (url) {
      setVideoUrl(url);
    }
  };

  const closeModal = () => {
    setShowModal(false);
    setState(_objectSpread(_objectSpread({}, state), {}, {
      playing: false,
      played: 0
    }));
  };

  (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(() => {
    const {
      observe
    } = lozad__WEBPACK_IMPORTED_MODULE_0___default()();
    observe();
  }, []);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("div", {
    className: "main lyt-content ",
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)("div", {
      className: "bs-banner homeSwiper js-bg ",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_4__.Swiper, {
        effect: "fade",
        fadeEffect: {
          crossFade: true
        },
        autoplay: {
          delay: 5000
        },
        pagination: {
          clickable: true
        } // navigation={true}
        ,
        children: banner.map((ele, index) => {
          var _ele$desktopImage, _ele$desktopImage2, _ele$mobileImage, _ele$desktopImage3;

          return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.Fragment, {
            children: ele.video ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.Fragment, {
              children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)(swiper_react__WEBPACK_IMPORTED_MODULE_4__.SwiperSlide, {
                className: "lozad-background hidden-xs js-video-slide typ-video lozad",
                "data-background-image": `${REACT_APP_BASE_URL}${ele.desktopImage.url}`,
                "data-swiper-autoplay": "22000",
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("video", {
                  width: "100%",
                  height: "100%",
                  autoPlay: true,
                  loop: true,
                  muted: true,
                  className: "lozad-picture lozad",
                  "data-poster": `${REACT_APP_BASE_URL}${ele.desktopImage.url}`,
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("source", {
                    src: '/assets/video/The Engineering Amada.mp4',
                    type: "video/mp4"
                  })
                }), ele.modalVideo && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)("button", {
                  className: "btn-play js-modal-btn",
                  "data-target": "videoModal",
                  onClick: () => {
                    var _ele$modalVideo;

                    return playVideo(ele.modalVideo !== null && ((_ele$modalVideo = ele.modalVideo) === null || _ele$modalVideo === void 0 ? void 0 : _ele$modalVideo.url));
                  },
                  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("span", {
                    className: "icon icon-full"
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("span", {
                    className: "text",
                    children: "View full video"
                  })]
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("span", {
                  className: "corner-shape"
                })]
              }, index)
            }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.Fragment, {
              children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)(swiper_react__WEBPACK_IMPORTED_MODULE_4__.SwiperSlide, {
                className: `slide-item ${ele.isProduct ? "typ-product" : ""}`,
                children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)("div", {
                  className: "banner-title-wrap",
                  children: [ele.isProduct ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("h2", {
                    className: "banner-title",
                    children: ele.title
                  }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("h2", {
                    className: "banner-title",
                    children: ele.title
                  }), ele.isProduct ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("p", {
                    className: "banner-sub-title",
                    children: ele.subtitle
                  }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("p", {
                    className: "banner-sub-title",
                    children: ele.subtitle
                  }), ele.isProduct && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__.default, {
                    href: ele.productURL,
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("a", {
                      className: "bs-btn btn-default",
                      children: "click here for details"
                    })
                  })]
                }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)("div", {
                  className: "banner-info mod-count-text",
                  children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)("div", {
                    className: "count",
                    children: [ele.step < 10 ? 0 : null, ele.step]
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("div", {
                    className: "text",
                    children: `${ele.stepName}`
                  })]
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("span", {
                  className: "corner-shape"
                }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)("picture", {
                  className: "banner-image",
                  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("source", {
                    srcSet: `${REACT_APP_BASE_URL}${(_ele$desktopImage = ele.desktopImage) === null || _ele$desktopImage === void 0 ? void 0 : _ele$desktopImage.url}`,
                    media: "(min-width: 1280px)"
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("source", {
                    srcSet: `${REACT_APP_BASE_URL}${(_ele$desktopImage2 = ele.desktopImage) === null || _ele$desktopImage2 === void 0 ? void 0 : _ele$desktopImage2.url}`,
                    media: "(min-width: 980px)"
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("source", {
                    srcSet: `${REACT_APP_BASE_URL}${(_ele$mobileImage = ele.mobileImage) === null || _ele$mobileImage === void 0 ? void 0 : _ele$mobileImage.url}`,
                    media: "(min-width: 320px)"
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("img", {
                    src: `${REACT_APP_BASE_URL}${(_ele$desktopImage3 = ele.desktopImage) === null || _ele$desktopImage3 === void 0 ? void 0 : _ele$desktopImage3.url}`,
                    alt: ele.title
                  })]
                })]
              }, index)
            })
          });
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_VideoModal__WEBPACK_IMPORTED_MODULE_5__/* .default */ .Z, {
        videoUrl: '/assets/video/The Engineering Amada.mp4',
        closeModal: closeModal,
        showModal: showModal,
        setState: setState,
        state: state
      })]
    })
  });
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Banner);
});

/***/ }),

/***/ 7824:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var lozad__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1790);
/* harmony import */ var lozad__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lozad__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2364);
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_seo__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);
/* eslint-disable @next/next/link-passhref */







const {
  REACT_APP_BASE_URL
} = process.env;

function Category({
  category
}) {
  var _category$product_cat, _category$product_cat2;

  (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(() => {
    const {
      observe
    } = lozad__WEBPACK_IMPORTED_MODULE_0___default()();
    observe();
  }, []); // console.log(category, 'catttt')

  var someDate = new Date();
  var numberOfDaysToAdd = 30;
  var result = someDate.setDate(someDate.getDate() + numberOfDaysToAdd); // console.log(new Date(result))

  function formatDate(date) {
    var d = new Date(date),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();
    if (month.length < 2) month = '0' + month;
    if (day.length < 2) day = '0' + day;
    return [year, month, day].join('-');
  } // console.log(formatDate(result));


  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)("div", {
    className: "bs-section sec-first",
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)("div", {
      className: "container",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
        className: "sec-head",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("h2", {
          className: "sec-title",
          children: "our products"
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
        className: "sec-cont",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
          className: "bs-product-grid",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("ul", {
            className: "list",
            children: category === null || category === void 0 ? void 0 : (_category$product_cat = category.product_categories) === null || _category$product_cat === void 0 ? void 0 : _category$product_cat.map((ele, ind) => {
              return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.Fragment, {
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("li", {
                  className: "item",
                  children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)("div", {
                    className: "bs-prod-card",
                    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__.default, {
                      href: `/${ele.slug}`,
                      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("a", {
                        className: "prod-link"
                      })
                    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
                      className: "img-wrap lozad-background lozad",
                      "data-background-image": `${REACT_APP_BASE_URL}${ele.smallImage.url}`
                    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
                      className: "info-wrap",
                      children: ele.title.length > 1 ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("h3", {
                        className: "title",
                        children: ele.title
                      }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("h3", {
                        className: "title",
                        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("span", {
                          className: "cm-line-break",
                          children: ele.title
                        })
                      })
                    })]
                  })
                }, ind)
              });
            })
          })
        })
      })]
    }), category === null || category === void 0 ? void 0 : (_category$product_cat2 = category.product_categories) === null || _category$product_cat2 === void 0 ? void 0 : _category$product_cat2.map((ele, i) => {
      // console.log('category=>>>> ', category )
      return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.Fragment, {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(next_seo__WEBPACK_IMPORTED_MODULE_1__.ProductJsonLd, {
          keyOverride: i,
          productName: ele.title,
          description: ele.title,
          images: [`${REACT_APP_BASE_URL}${ele.smallImage.url}`],
          brand: "Amada",
          manufacturerName: "Amada",
          manufacturerLogo: "https://www.amada.ae/assets/images/logo.png",
          releaseDate: ele.published_at,
          reviews: [{
            author: {
              type: 'Organization',
              name: 'Amada Middle East FZCO'
            },
            datePublished: ele.published_at,
            reviewBody: ele.title,
            name: ele.title,
            reviewRating: {
              bestRating: '5',
              ratingValue: '5',
              worstRating: '1'
            },
            publisher: {
              type: 'Organization',
              name: 'Amada Middle East FZCO'
            }
          }],
          aggregateRating: {
            ratingValue: '4.5',
            reviewCount: '10'
          },
          offers: [{
            url: `https://www.amada.ae/${ele.slug}`,
            availability: 'InStock',
            seller: {
              name: 'Amada Middle East FZCO'
            },
            priceValidUntil: formatDate(result)
          }],
          mpn: ele.title,
          sku: "Amada Middle East FZCO"
        })
      });
    })]
  });
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Category);

/***/ }),

/***/ 1625:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var lozad__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1790);
/* harmony import */ var lozad__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lozad__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2364);
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_seo__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2167);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);
/* eslint-disable @next/next/no-img-element */







const {
  REACT_APP_BASE_URL
} = process.env;

function News({
  event
}) {
  var _event$news_events, _event$news_events2;

  (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(() => {
    const {
      observe
    } = lozad__WEBPACK_IMPORTED_MODULE_0___default()();
    observe();
  }, []);
  var newSort = event === null || event === void 0 ? void 0 : (_event$news_events = event.news_events) === null || _event$news_events === void 0 ? void 0 : _event$news_events.sort((a, b) => a.date < b.date && 1 || -1);
  var linkedin = newSort.filter(el => el.isLinkedin);
  var notLinkedin = newSort.filter(el => !el.isLinkedin);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)("div", {
    className: "bs-section",
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)("div", {
      className: "container",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
        className: "sec-head",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("h2", {
          className: "sec-title",
          children: "what's new"
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
        className: "sec-cont",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
          className: "lyt-news",
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)("ul", {
            className: "list",
            children: [linkedin === null || linkedin === void 0 ? void 0 : linkedin.slice(0, 3).map((ele, index) => {
              var _ele$smallImage, _ele$smallImage2;

              return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.Fragment, {
                children: ele.isLinkedin && ele.url && ((_ele$smallImage = ele.smallImage) === null || _ele$smallImage === void 0 ? void 0 : _ele$smallImage.url) && ele.title && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.Fragment, {
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("li", {
                    className: "item",
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
                      className: "bs-img-overlay",
                      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)("div", {
                        className: "img-wrap bs-news lozad-background lozad",
                        "data-background-image": `${REACT_APP_BASE_URL}${(_ele$smallImage2 = ele.smallImage) === null || _ele$smallImage2 === void 0 ? void 0 : _ele$smallImage2.url}`,
                        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(next_dist_client_link__WEBPACK_IMPORTED_MODULE_2__.default, {
                          href: ele.url,
                          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("a", {
                            className: "news-link",
                            target: "_blank"
                          })
                        }, index), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("span", {
                          className: "icon icon-linkedin"
                        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)("div", {
                          className: "news-info",
                          children: [ele.url && ele.date && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("time", {
                            dateTime: "2020-08",
                            className: "date",
                            children: `${new Date(ele.date).toLocaleString("default", {
                              month: "long"
                            })} 
                                    ${new Date(ele.date).toLocaleString("default", {
                              year: "numeric"
                            })}`
                          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("p", {
                            className: "desc",
                            children: ele.title
                          })]
                        })]
                      })
                    })
                  }, index)
                })
              });
            }), notLinkedin === null || notLinkedin === void 0 ? void 0 : notLinkedin.slice(0, 2).map((ele, index) => {
              var _ele$smallImage3, _ele$smallImage4;

              return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.Fragment, {
                children: !ele.isLinkedin && ((_ele$smallImage3 = ele.smallImage) === null || _ele$smallImage3 === void 0 ? void 0 : _ele$smallImage3.url) && ele.title && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("li", {
                  className: "item",
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
                    className: "bs-img-overlay",
                    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)("div", {
                      className: "img-wrap bs-news lozad-background lozad",
                      "data-background-image": `${REACT_APP_BASE_URL}${(_ele$smallImage4 = ele.smallImage) === null || _ele$smallImage4 === void 0 ? void 0 : _ele$smallImage4.url}`,
                      children: [ele.gallery.length === 0 && ele.pdfFile && ele.pdfFile.url ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("a", {
                        href: `${REACT_APP_BASE_URL}${ele.pdfFile.url}`,
                        target: "_blank",
                        rel: "noreferrer",
                        className: "news-link"
                      }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(next_dist_client_link__WEBPACK_IMPORTED_MODULE_2__.default, {
                        href: `/news-events/${ele.slug}`,
                        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("a", {
                          className: "news-link"
                        })
                      }, index), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
                        className: "news-info",
                        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("p", {
                          className: "desc",
                          children: ele.title
                        })
                      })]
                    })
                  })
                }, index)
              });
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("li", {
              className: "item",
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(next_dist_client_link__WEBPACK_IMPORTED_MODULE_2__.default, {
                href: "/news-events",
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("button", {
                  className: "bs-btn btn-tile",
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("span", {
                    className: "text",
                    children: "more in news"
                  })
                })
              })
            })]
          })
        })
      })]
    }), event === null || event === void 0 ? void 0 : (_event$news_events2 = event.news_events) === null || _event$news_events2 === void 0 ? void 0 : _event$news_events2.map((ele, i) => {
      var _ele$smallImage5;

      return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.Fragment, {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(next_seo__WEBPACK_IMPORTED_MODULE_1__.NewsArticleJsonLd, {
          keyOverride: i,
          url: ele.isLinkedin ? ele.url : `https://www.amada.ae/news-events/${ele.slug}`,
          title: ele.title,
          images: [`${REACT_APP_BASE_URL}${(_ele$smallImage5 = ele.smallImage) === null || _ele$smallImage5 === void 0 ? void 0 : _ele$smallImage5.url}`],
          section: "technology",
          datePublished: ele.date,
          authorName: "Amada",
          publisherName: "Amada Bureau",
          body: ele.title,
          publisherLogo: "https://www.amada.ae/assets/images/logo.png"
        })
      });
    })]
  });
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (News);

/***/ }),

/***/ 6124:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps),
/* harmony export */   "default": () => (/* binding */ Home)
/* harmony export */ });
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2364);
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_seo__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(701);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_Global_Layout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6839);
/* harmony import */ var _components_Home_About__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2471);
/* harmony import */ var _components_Home_Banner__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8769);
/* harmony import */ var _components_Home_Category__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7824);
/* harmony import */ var _components_Home_News__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1625);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Home_About__WEBPACK_IMPORTED_MODULE_3__, _components_Home_Banner__WEBPACK_IMPORTED_MODULE_4__]);
([_components_Home_About__WEBPACK_IMPORTED_MODULE_3__, _components_Home_Banner__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);










async function getServerSideProps() {
  const res = await fetch(`${"https://strapi.amada.ae"}/home-page`);
  const json = await res.json();
  return {
    props: {
      banner: json.banner,
      category: json.productCategorySection,
      event: json.whatsNewSection,
      seo: json.seo,
      info: json.infoSection
    }
  };
}
function Home({
  banner,
  category,
  event,
  seo,
  info
}) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(_components_Global_Layout__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z, {
      activeLink: "Home",
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("title", {
          children: "AMADA MIDDLE EAST FZCO"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("link", {
          rel: "icon",
          href: "../static/favicon.ico"
        })]
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_components_Home_Banner__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z, {
        banner: banner
      }), category.isActive && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_components_Home_Category__WEBPACK_IMPORTED_MODULE_5__/* .default */ .Z, {
        category: category
      }), info.isActive && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_components_Home_About__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z, {
        info: info
      }), event.isActive && event.news_events.length > 0 && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_components_Home_News__WEBPACK_IMPORTED_MODULE_6__/* .default */ .Z, {
        event: event
      })]
    }), seo !== null && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(next_seo__WEBPACK_IMPORTED_MODULE_0__.NextSeo, {
      title: seo.metaTitle,
      description: seo.metaDescription,
      keyword: seo.metaKeyword,
      noindex: seo.noIndex,
      nofollow: seo.noFollow
    }, seo.metaTitle)]
  });
}
});

/***/ }),

/***/ 1790:
/***/ ((module) => {

module.exports = require("lozad");

/***/ }),

/***/ 2364:
/***/ ((module) => {

module.exports = require("next-seo");

/***/ }),

/***/ 9325:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 5378:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 7162:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 8773:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 2248:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 9372:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 665:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 2747:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 333:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 3456:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 7620:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 701:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 9297:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 3703:
/***/ ((module) => {

module.exports = import("react-markdown");;

/***/ }),

/***/ 6311:
/***/ ((module) => {

module.exports = require("react-player");

/***/ }),

/***/ 5282:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 4074:
/***/ ((module) => {

module.exports = import("swiper");;

/***/ }),

/***/ 2156:
/***/ ((module) => {

module.exports = import("swiper/react");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [664,525,279], () => (__webpack_exec__(6124)));
module.exports = __webpack_exports__;

})();