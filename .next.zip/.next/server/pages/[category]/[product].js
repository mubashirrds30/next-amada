"use strict";
(() => {
var exports = {};
exports.id = 891;
exports.ids = [891];
exports.modules = {

/***/ 5958:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2364);
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_seo__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);






function ProductBreadcrum({
  product
}) {
  var _product$product_cate, _product$product_cate2, _product$product_cate3, _product$product_cate4, _product$product_cate5, _product$product_cate6;

  // console.log(product)
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
    className: "bs-breadcrum",
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
      className: "container",
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("ul", {
        className: "list",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("li", {
          className: "item",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__.default, {
            href: "/",
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("a", {
              className: "link",
              children: "amada"
            })
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("li", {
          className: "item",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("a", {
            href: "javascript:void(0)",
            className: "link",
            children: "products"
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("li", {
          className: "item",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__.default, {
            href: `/${product === null || product === void 0 ? void 0 : (_product$product_cate = product.product_category) === null || _product$product_cate === void 0 ? void 0 : _product$product_cate.slug}`,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("a", {
              className: "link",
              children: product === null || product === void 0 ? void 0 : (_product$product_cate2 = product.product_category) === null || _product$product_cate2 === void 0 ? void 0 : _product$product_cate2.title
            })
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("li", {
          className: "item",
          children: product === null || product === void 0 ? void 0 : product.name
        })]
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(next_seo__WEBPACK_IMPORTED_MODULE_0__.BreadcrumbJsonLd, {
      itemListElements: [{
        position: 1,
        name: 'amada',
        item: `https://www.amada.ae/`
      }, {
        position: 2,
        name: 'products',
        item: `https://www.amada.ae/${product === null || product === void 0 ? void 0 : (_product$product_cate3 = product.product_category) === null || _product$product_cate3 === void 0 ? void 0 : _product$product_cate3.slug}`
      }, {
        position: 3,
        name: product === null || product === void 0 ? void 0 : (_product$product_cate4 = product.product_category) === null || _product$product_cate4 === void 0 ? void 0 : _product$product_cate4.title,
        item: `https://www.amada.ae/${product === null || product === void 0 ? void 0 : (_product$product_cate5 = product.product_category) === null || _product$product_cate5 === void 0 ? void 0 : _product$product_cate5.slug}`
      }, {
        position: 4,
        name: product === null || product === void 0 ? void 0 : product.name,
        item: `https://www.amada.ae/${product === null || product === void 0 ? void 0 : (_product$product_cate6 = product.product_category) === null || _product$product_cate6 === void 0 ? void 0 : _product$product_cate6.slug}/${product === null || product === void 0 ? void 0 : product.slug}`
      }]
    })]
  });
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductBreadcrum);

/***/ }),

/***/ 2510:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);





function ProductFeatures({
  product
}) {
  var _product$features, _product$features2, _product$features3, _product$features3$fe, _product$features4, _product$features4$fe;

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {
    className: "bs-features",
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {
      className: "lyt-features",
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
        className: "",
        children: [((_product$features = product.features) === null || _product$features === void 0 ? void 0 : _product$features.heading) && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("h2", {
          className: "title",
          children: (_product$features2 = product.features) === null || _product$features2 === void 0 ? void 0 : _product$features2.heading
        }), (product === null || product === void 0 ? void 0 : (_product$features3 = product.features) === null || _product$features3 === void 0 ? void 0 : (_product$features3$fe = _product$features3.featuresSection) === null || _product$features3$fe === void 0 ? void 0 : _product$features3$fe.length) > 0 && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {
          className: "sec-desc",
          children: product === null || product === void 0 ? void 0 : (_product$features4 = product.features) === null || _product$features4 === void 0 ? void 0 : (_product$features4$fe = _product$features4.featuresSection) === null || _product$features4$fe === void 0 ? void 0 : _product$features4$fe.map((ele, index) => {
            var _ele$point;

            return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("h3", {
                className: "sub-title",
                children: ele.subTitle
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("ul", {
                className: "mod-list",
                children: ele === null || ele === void 0 ? void 0 : (_ele$point = ele.point) === null || _ele$point === void 0 ? void 0 : _ele$point.map((ele, i) => {
                  var _ele$subPoint;

                  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
                    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("li", {
                      className: "item",
                      children: [ele.point, ele.subPoint && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
                        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("ul", {
                          className: "inside-list",
                          children: (_ele$subPoint = ele.subPoint) === null || _ele$subPoint === void 0 ? void 0 : _ele$subPoint.map((el, inn) => {
                            return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("li", {
                              children: el.subPoint
                            }, inn);
                          })
                        })
                      })]
                    }, i)
                  });
                })
              })]
            }, index);
          })
        })]
      })
    })
  });
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductFeatures);

/***/ }),

/***/ 1455:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var lozad__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1790);
/* harmony import */ var lozad__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lozad__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_markdown__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3703);
/* harmony import */ var _Home_VideoModal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7279);
/* harmony import */ var _Table_Specs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4428);
/* harmony import */ var _ProductFeatures__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2510);
/* harmony import */ var _ProductSubFeature__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2650);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_ProductSubFeature__WEBPACK_IMPORTED_MODULE_6__, react_markdown__WEBPACK_IMPORTED_MODULE_2__]);
([_ProductSubFeature__WEBPACK_IMPORTED_MODULE_6__, react_markdown__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/* eslint-disable @next/next/no-img-element */









const {
  REACT_APP_BASE_URL
} = process.env;

function ProductInfo({
  product
}) {
  var _JSON$parse, _product$specificatio;

  // console.log("info====>", product);
  const {
    0: showModal,
    1: setShowModal
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
  const {
    0: videoUrl,
    1: setVideoUrl
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
  const {
    0: state,
    1: setState
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
    playing: false,
    played: 0,
    seeking: false
  });

  const playVideo = url => {
    setShowModal(true);

    if (url) {
      setVideoUrl(url);
    }
  };

  const closeModal = () => {
    setShowModal(false);
    setState(_objectSpread(_objectSpread({}, state), {}, {
      playing: false,
      played: 0
    }));
  };

  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
    const {
      observe
    } = lozad__WEBPACK_IMPORTED_MODULE_0___default()();
    observe();
  }, []);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("section", {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_Home_VideoModal__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z, {
        videoUrl: product.oembed !== null && product.oembed && (JSON === null || JSON === void 0 ? void 0 : (_JSON$parse = JSON.parse(product === null || product === void 0 ? void 0 : product.oembed)) === null || _JSON$parse === void 0 ? void 0 : _JSON$parse.url),
        closeModal: closeModal,
        showModal: showModal,
        setState: setState,
        state: state,
        product: true,
        controls: true
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("div", {
        className: "bs-section",
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
          className: "container",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("div", {
            className: "sec-head",
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("h2", {
              className: "sec-title",
              children: product === null || product === void 0 ? void 0 : product.name
            })
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
            className: "sec-cont bs-img-desc typ-vertical",
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("div", {
              className: "img-wrap",
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("img", {
                className: "lozad",
                alt: product.name,
                "data-src": `${REACT_APP_BASE_URL}${product.largeImage.url}`
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("p", {
              className: "sub-title",
              children: product === null || product === void 0 ? void 0 : product.title
            }), (product === null || product === void 0 ? void 0 : product.description) && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("div", {
              className: "sec-desc",
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("p", {
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(react_markdown__WEBPACK_IMPORTED_MODULE_2__.default, {
                  className: "rich-text",
                  children: product === null || product === void 0 ? void 0 : product.description
                })
              })
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
              className: "action-wrap",
              children: [product.brochure && product.brochure !== null && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("a", {
                href: `${REACT_APP_BASE_URL}${product.brochure.url}`,
                className: "bs-btn btn-default download-btn",
                target: "_blank",
                rel: "noreferrer",
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("span", {
                  className: "icon icon-download"
                }), "download brochure"]
              }), product.ebookLink && product.ebookLink !== null && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("a", {
                href: `${product.ebookLink}`,
                className: "bs-btn btn-default download-btn",
                target: "_blank",
                rel: "noreferrer",
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("span", {
                  className: "icon icon-download"
                }), "download E-book"]
              }), product.oembed && product.oembed !== null && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("button", {
                className: "bs-btn btn-icon-link btn-play js-modal-btn",
                "data-target": "videoModal",
                onClick: () => playVideo(product.oembed !== null && product.oembed),
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("span", {
                  className: "icon icon-full"
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("span", {
                  className: "text",
                  children: "Watch Product Video"
                })]
              })]
            })]
          })]
        })
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("section", {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("div", {
        className: "bs-section typ-product-intro",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("div", {
          className: "container",
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
            className: "bs-product-detail",
            children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
              className: "pd-head",
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_ProductFeatures__WEBPACK_IMPORTED_MODULE_5__/* .default */ .Z, {
                product: product
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_ProductSubFeature__WEBPACK_IMPORTED_MODULE_6__/* .default */ .Z, {
                product: product
              })]
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("div", {
              className: "pd-body",
              children: product === null || product === void 0 ? void 0 : (_product$specificatio = product.specifications) === null || _product$specificatio === void 0 ? void 0 : _product$specificatio.map((pro, i) => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
                className: "bs-table",
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("h3", {
                  className: "title",
                  children: pro.heading
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_Table_Specs__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z, {
                  product: pro.table
                })]
              }, i))
            })]
          })
        })
      })
    })]
  });
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductInfo);
});

/***/ }),

/***/ 2650:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var lozad__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1790);
/* harmony import */ var lozad__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lozad__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_markdown__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3703);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_markdown__WEBPACK_IMPORTED_MODULE_2__]);
react_markdown__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];
/* eslint-disable @next/next/no-img-element */






const {
  REACT_APP_BASE_URL
} = process.env;

function ProductSubFeature({
  product
}) {
  var _product$subFeatures, _product$subFeatures2;

  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
    const {
      observe
    } = lozad__WEBPACK_IMPORTED_MODULE_0___default()();
    observe();
  }, []);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
    children: (product === null || product === void 0 ? void 0 : (_product$subFeatures = product.subFeatures) === null || _product$subFeatures === void 0 ? void 0 : _product$subFeatures.length) > 0 && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.Fragment, {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
        className: "pd-head",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("ul", {
          className: "bs-chain-info",
          children: product === null || product === void 0 ? void 0 : (_product$subFeatures2 = product.subFeatures) === null || _product$subFeatures2 === void 0 ? void 0 : _product$subFeatures2.map((ele, ind) => {
            var _ele$subFeaturesPoint;

            return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.Fragment, {
              children: (_ele$subFeaturesPoint = ele.subFeaturesPoint) === null || _ele$subFeaturesPoint === void 0 ? void 0 : _ele$subFeaturesPoint.map((el, i) => {
                var _el$image, _el$image2;

                return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.Fragment, {
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("li", {
                    className: "item",
                    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
                      className: "bs-img-desc",
                      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
                        className: "left-side",
                        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
                          className: "img-wrap",
                          children: ((_el$image = el.image) === null || _el$image === void 0 ? void 0 : _el$image.url) && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("img", {
                            className: "lozad",
                            alt: product.name,
                            "data-src": `${REACT_APP_BASE_URL}${el.image.url}`
                          })
                        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
                          className: "sec-desc",
                          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("h2", {
                            className: "sub-title",
                            children: ele.title
                          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("p", {
                            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(react_markdown__WEBPACK_IMPORTED_MODULE_2__.default, {
                              className: "rich-text",
                              children: el.description
                            })
                          })]
                        })]
                      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
                        className: "right-side",
                        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
                          className: "img-wrap",
                          children: ((_el$image2 = el.image) === null || _el$image2 === void 0 ? void 0 : _el$image2.url) && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("img", {
                            className: "lozad",
                            alt: product.name,
                            "data-src": `${REACT_APP_BASE_URL}${el.image.url}`
                          })
                        })
                      })]
                    })
                  }, i)
                });
              })
            });
          })
        })
      })
    })
  });
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductSubFeature);
});

/***/ }),

/***/ 4428:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);




function Specs({
  product
}) {
  // console.log("table  ==>", product);
  let top = {};
  product === null || product === void 0 ? void 0 : product.map((ele, i) => {
    var _product$;

    top["name"] = (_product$ = product[0]) === null || _product$ === void 0 ? void 0 : _product$.title;
    top["unit"] = "";
    top["col" + i] = ele.model;
  }); // console.log("top row ====>", top);
  //static json conversion of Beta Object

  let specifications = [top];
  product[0].tableData.map(ele => {
    var _ele$fieldName, _ele$data;

    let tempObj = {};
    tempObj["name"] = (ele === null || ele === void 0 ? void 0 : (_ele$fieldName = ele.fieldName) === null || _ele$fieldName === void 0 ? void 0 : _ele$fieldName.trim()) || "";
    tempObj["unit"] = (ele === null || ele === void 0 ? void 0 : ele.unit) || "";
    tempObj["col0"] = (ele === null || ele === void 0 ? void 0 : (_ele$data = ele.data) === null || _ele$data === void 0 ? void 0 : _ele$data.trim()) || "";
    let betaCopy = product === null || product === void 0 ? void 0 : product.slice(1);
    betaCopy.map((item, index) => {
      var _item$tableData, _temp$, _temp$$data;

      let temp = item === null || item === void 0 ? void 0 : (_item$tableData = item.tableData) === null || _item$tableData === void 0 ? void 0 : _item$tableData.filter(element => {
        var _element$fieldName, _ele$fieldName2;

        return ((_element$fieldName = element.fieldName) === null || _element$fieldName === void 0 ? void 0 : _element$fieldName.toLowerCase().trim()) === ((_ele$fieldName2 = ele.fieldName) === null || _ele$fieldName2 === void 0 ? void 0 : _ele$fieldName2.toLowerCase().trim());
      });
      tempObj["col" + (index + 1)] = (_temp$ = temp[0]) === null || _temp$ === void 0 ? void 0 : (_temp$$data = _temp$.data) === null || _temp$$data === void 0 ? void 0 : _temp$$data.trim();
    });
    specifications.push(tempObj);
  }); // console.log("specifications", specifications);
  ///////////////////////////////////////////

  const allEqual = arr => arr.every(val => val === arr[0] || val === undefined);

  const {
    0: state,
    1: setState
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(specifications);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {
    className: "table-wrap",
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("table", {
      className: "table",
      cellPadding: "0",
      cellSpacing: "0",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("thead", {
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("tr", {
          children: [Object.values(state[0]).map((key, index) => index === 0 && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("th", {
            colSpan: 2,
            children: key
          }, index)), Object.values(state[0]).map((key, index) => index >= 2 && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("th", {
            style: {
              textAlign: "center"
            },
            children: key
          }, index))]
        }, "header")
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("tbody", {
        children: state.slice(1).map((item, index) => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("tr", {
          children: [Object.values(item).slice(0, 1).map((val, i) => i === 0 && !item.unit ? i === 0 && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("td", {
            colSpan: 2,
            className: "t-desc",
            children: val
          }, val) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("td", {
            className: "t-desc",
            children: val
          }, val)), Object.values(item).slice(1, 2).map((val, i) => item.unit && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("td", {
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("span", {
              className: "cm-bold",
              children: val
            }, i)
          }, i)), allEqual(Object.values(item).slice(2)) ? Object.values(item).slice(2, 3).map((val, i) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("td", {
            style: {
              textAlign: "center"
            },
            colSpan: Object.values(item).slice(2).length,
            className: "t-desc",
            children: val
          }, i)) : Object.values(item).slice(2).map((val, i) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("td", {
            style: {
              textAlign: "center"
            },
            className: "t-desc",
            children: val
          }, i))]
        }, index))
      })]
    })
  });
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Specs);

/***/ }),

/***/ 4499:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var lozad__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1790);
/* harmony import */ var lozad__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lozad__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2364);
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_seo__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(701);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6731);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_Global_Layout__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6839);
/* harmony import */ var _components_Product_ProductBreadcrum__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5958);
/* harmony import */ var _components_Product_ProductInfo__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1455);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Product_ProductInfo__WEBPACK_IMPORTED_MODULE_7__]);
_components_Product_ProductInfo__WEBPACK_IMPORTED_MODULE_7__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];
/* eslint-disable @next/next/no-img-element */











const getServerSideProps = async context => {
  const slug = context.params.product;
  const res = await fetch(`${"https://strapi.amada.ae"}/products?slug=${slug}`);
  const json = await res.json();

  if (json.length > 0) {
    return {
      props: {
        data: json
      }
    };
  } else {
    return {
      notFound: true
    };
  }
};

function Product({
  data
}) {
  var _product$smallImage, _product$product_cate;

  (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(() => {
    const {
      observe
    } = lozad__WEBPACK_IMPORTED_MODULE_0___default()();
    observe();
  }, []);
  const nextRouter = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
  const product = data[0]; // console.log(product, 'prooo')

  var someDate = new Date();
  var numberOfDaysToAdd = 30;
  var result = someDate.setDate(someDate.getDate() + numberOfDaysToAdd); // console.log(new Date(result))

  function formatDate(date) {
    var d = new Date(date),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();
    if (month.length < 2) month = '0' + month;
    if (day.length < 2) day = '0' + day;
    return [year, month, day].join('-');
  }

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_2___default()), {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("title", {
        children: product.name
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("link", {
        rel: "icon",
        href: "../static/favicon.ico"
      })]
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)(_components_Global_Layout__WEBPACK_IMPORTED_MODULE_5__/* .default */ .Z, {
      activeLink: "Products",
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("main", {
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("div", {
          className: "main lyt-content js-bg",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_components_Product_ProductBreadcrum__WEBPACK_IMPORTED_MODULE_6__/* .default */ .Z, {
            product: product
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_components_Product_ProductInfo__WEBPACK_IMPORTED_MODULE_7__/* .default */ .Z, {
            product: product
          })]
        }), product.seo !== null && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(next_seo__WEBPACK_IMPORTED_MODULE_1__.NextSeo, {
          title: product.seo.metaTitle,
          description: product.seo.metaDescription,
          keyword: product.seo.metaKeyword,
          noindex: product.seo.noIndex,
          nofollow: product.seo.noFollow
        }, product.seo.metaTitle)]
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(next_seo__WEBPACK_IMPORTED_MODULE_1__.ProductJsonLd, {
        productName: product.name,
        images: [`${"https://strapi.amada.ae"}${product === null || product === void 0 ? void 0 : (_product$smallImage = product.smallImage) === null || _product$smallImage === void 0 ? void 0 : _product$smallImage.url}`],
        description: product.description,
        brand: "Amada",
        manufacturerName: "AMADA MIDDLE EAST FZCO",
        manufacturerLogo: "https://www.amada.ae/assets/images/logo.png",
        releaseDate: product.published_at,
        aggregateRating: {
          ratingValue: '4.5',
          reviewCount: '10'
        },
        reviews: [{
          author: {
            type: 'Organization',
            name: 'Amada Middle East FZCO'
          },
          datePublished: product.published_at,
          reviewBody: product.description,
          name: product.name,
          reviewRating: {
            bestRating: '5',
            ratingValue: '5',
            worstRating: '1'
          },
          publisher: {
            type: 'Organization',
            name: 'Amada Middle East FZCO'
          }
        }],
        offers: [{
          // priceCurrency: 'INR',
          url: `https://www.amada.ae/${product === null || product === void 0 ? void 0 : (_product$product_cate = product.product_category) === null || _product$product_cate === void 0 ? void 0 : _product$product_cate.slug}/${product.slug}`,
          availability: 'InStock',
          seller: {
            name: 'Amada Middle East FZCO'
          },
          priceValidUntil: formatDate(result)
        }],
        mpn: product.name,
        sku: "Amada Middle East FZCO"
      })]
    })]
  });
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Product);
});

/***/ }),

/***/ 1790:
/***/ ((module) => {

module.exports = require("lozad");

/***/ }),

/***/ 2364:
/***/ ((module) => {

module.exports = require("next-seo");

/***/ }),

/***/ 9325:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 5378:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 7162:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 8773:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 2248:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 9372:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 665:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 2747:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 333:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 3456:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 7620:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 701:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6731:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 9297:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 3703:
/***/ ((module) => {

module.exports = import("react-markdown");;

/***/ }),

/***/ 6311:
/***/ ((module) => {

module.exports = require("react-player");

/***/ }),

/***/ 5282:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [664,525,279], () => (__webpack_exec__(4499)));
module.exports = __webpack_exports__;

})();