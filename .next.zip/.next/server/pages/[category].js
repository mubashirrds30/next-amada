"use strict";
(() => {
var exports = {};
exports.id = 716;
exports.ids = [716];
exports.modules = {

/***/ 44:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var lozad__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1790);
/* harmony import */ var lozad__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lozad__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);




const {
  REACT_APP_BASE_URL
} = process.env;

function Banner({
  product
}) {
  var _product$largeImage;

  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
    const {
      observe
    } = lozad__WEBPACK_IMPORTED_MODULE_0___default()();
    observe();
  }, []);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("div", {
    className: "bs-banner typ-sm lozad-background lozad",
    "data-background-image": `${REACT_APP_BASE_URL}${product === null || product === void 0 ? void 0 : (_product$largeImage = product.largeImage) === null || _product$largeImage === void 0 ? void 0 : _product$largeImage.url}`,
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
      className: "banner-title-wrap",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("h2", {
        className: "banner-title",
        children: product === null || product === void 0 ? void 0 : product.title
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("span", {
      className: "corner-shape"
    })]
  });
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Banner);

/***/ }),

/***/ 7766:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2364);
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_seo__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);






function Breadcrum({
  product,
  slug
}) {
  // console.log(product, slug)
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
    className: "bs-breadcrum",
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
      className: "container",
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("ul", {
        className: "list",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("li", {
          className: "item",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__.default, {
            href: "/",
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("a", {
              className: "link",
              children: "amada"
            })
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("li", {
          className: "item",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("a", {
            href: "javascript:void(0)",
            className: "link",
            children: "Products"
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("li", {
          className: "item",
          children: product === null || product === void 0 ? void 0 : product.title
        })]
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(next_seo__WEBPACK_IMPORTED_MODULE_0__.BreadcrumbJsonLd, {
      itemListElements: [{
        position: 1,
        name: 'amada',
        item: `https://www.amada.ae`
      }, {
        position: 2,
        name: 'products',
        item: `https://www.amada.ae/${slug}`
      }, {
        position: 3,
        name: product === null || product === void 0 ? void 0 : product.title,
        item: `https://www.amada.ae/${slug}`
      }]
    })]
  });
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Breadcrum);

/***/ }),

/***/ 8928:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var lozad__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1790);
/* harmony import */ var lozad__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lozad__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_markdown__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3703);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_markdown__WEBPACK_IMPORTED_MODULE_3__]);
react_markdown__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];
/* eslint-disable @next/next/no-img-element */






const {
  REACT_APP_BASE_URL
} = process.env;

function Products({
  product,
  slug
}) {
  var _product$productSecti, _product$productSecti2;

  (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(() => {
    const {
      observe
    } = lozad__WEBPACK_IMPORTED_MODULE_0___default()();
    observe();
  }, []);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("section", {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
        className: "bs-section sec-first",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
          className: "container",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
            className: "sec-cont",
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("ul", {
              className: "bs-chain-info typ-listing",
              children: product === null || product === void 0 ? void 0 : (_product$productSecti = product.productSection) === null || _product$productSecti === void 0 ? void 0 : (_product$productSecti2 = _product$productSecti.products) === null || _product$productSecti2 === void 0 ? void 0 : _product$productSecti2.map((ele, index) => {
                var _ele$smallImage, _ele$smallImage2;

                return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("li", {
                  className: "item",
                  children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)("div", {
                    className: "bs-img-desc",
                    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)("div", {
                      className: "left-side",
                      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("h2", {
                        className: "title",
                        children: ele.name
                      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
                        className: "img-wrap",
                        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("img", {
                          className: "lozad",
                          alt: ele.name,
                          "data-src": `${REACT_APP_BASE_URL}${(_ele$smallImage = ele.smallImage) === null || _ele$smallImage === void 0 ? void 0 : _ele$smallImage.url}`
                        })
                      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
                        className: "sec-desc",
                        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(react_markdown__WEBPACK_IMPORTED_MODULE_3__.default, {
                          className: "rich-text",
                          children: ele.intro
                        })
                      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)("div", {
                        className: "action-wrap",
                        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__.default, {
                          href: `/${slug}/${ele.slug}`,
                          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("a", {
                            className: "bs-btn btn-default",
                            children: "know more"
                          })
                        }), ele.brochure && product.brochure !== null && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("a", {
                          href: `${REACT_APP_BASE_URL}${ele.brochure.url}`,
                          target: "_blank",
                          rel: "noreferrer",
                          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)("button", {
                            className: "bs-btn btn-icon-link download-btn",
                            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("span", {
                              className: "icon icon-download"
                            }), "download brochure"]
                          })
                        })]
                      })]
                    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
                      className: "right-side",
                      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
                        className: "img-wrap lozad-background lozad",
                        "data-background-image": `${REACT_APP_BASE_URL}${(_ele$smallImage2 = ele.smallImage) === null || _ele$smallImage2 === void 0 ? void 0 : _ele$smallImage2.url}`
                      })
                    })]
                  })
                }, index);
              })
            })
          })
        })
      })
    })
  });
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Products);
});

/***/ }),

/***/ 7208:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var lozad__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1790);
/* harmony import */ var lozad__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lozad__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2364);
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_seo__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(701);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6731);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_Global_Layout__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6839);
/* harmony import */ var _components_Product_Listing_Banner__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(44);
/* harmony import */ var _components_Product_Listing_Breadcrum__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7766);
/* harmony import */ var _components_Product_Listing_Products__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8928);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Product_Listing_Products__WEBPACK_IMPORTED_MODULE_8__]);
_components_Product_Listing_Products__WEBPACK_IMPORTED_MODULE_8__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];
/* eslint-disable @next/next/no-img-element */












const getServerSideProps = async context => {
  const id = context.params.category;
  const res = await fetch(`${"https://strapi.amada.ae"}/product-categories?slug=${id}`);
  const json = await res.json();

  if (json.length > 0) {
    return {
      props: {
        data: json,
        slug: id
      }
    };
  } else {
    return {
      notFound: true
    };
  }
};

function Category({
  data,
  slug
}) {
  var _product$productSecti, _product$productSecti2;

  (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(() => {
    const {
      observe
    } = lozad__WEBPACK_IMPORTED_MODULE_0___default()();
    observe();
  }, []);
  const nextRouter = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)(); // if (data.length > 0) {
  // } else {
  //   if (nextRouter != undefined) {
  //     typeof window !== "undefined" && nextRouter.push("/404");
  //   }
  //   return false;
  // }

  const product = data[0];
  var someDate = new Date();
  var numberOfDaysToAdd = 30;
  var result = someDate.setDate(someDate.getDate() + numberOfDaysToAdd); // console.log(new Date(result))

  function formatDate(date) {
    var d = new Date(date),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();
    if (month.length < 2) month = '0' + month;
    if (day.length < 2) day = '0' + day;
    return [year, month, day].join('-');
  }

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.Fragment, {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("main", {
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_2___default()), {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("title", {
          children: product.title
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("link", {
          rel: "icon",
          href: "../static/favicon.ico"
        })]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(_components_Global_Layout__WEBPACK_IMPORTED_MODULE_5__/* .default */ .Z, {
        activeLink: "Products",
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
          className: "main lyt-content js-bg",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_components_Product_Listing_Banner__WEBPACK_IMPORTED_MODULE_6__/* .default */ .Z, {
            product: product
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_components_Product_Listing_Breadcrum__WEBPACK_IMPORTED_MODULE_7__/* .default */ .Z, {
            product: product,
            slug: slug
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_components_Product_Listing_Products__WEBPACK_IMPORTED_MODULE_8__/* .default */ .Z, {
            product: product,
            slug: slug
          })]
        }), product.seo !== null && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(next_seo__WEBPACK_IMPORTED_MODULE_1__.NextSeo, {
          title: product.seo.metaTitle,
          description: product.seo.metaDescription,
          keyword: product.seo.metaKeyword,
          noindex: product.seo.noIndex,
          nofollow: product.seo.noFollow
        })]
      }), (_product$productSecti = product.productSection) === null || _product$productSecti === void 0 ? void 0 : (_product$productSecti2 = _product$productSecti.products) === null || _product$productSecti2 === void 0 ? void 0 : _product$productSecti2.map((ele, i) => {
        // console.log('product=====', product)
        return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.Fragment, {
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(next_seo__WEBPACK_IMPORTED_MODULE_1__.ProductJsonLd, {
            keyOverride: i,
            productName: ele.name,
            images: [`${"https://strapi.amada.ae"}${ele.smallImage.url}`],
            description: ele.description,
            brand: "Amada",
            manufacturerName: "AMADA MIDDLE EAST FZCO",
            manufacturerLogo: "https://www.amada.ae/assets/images/logo.png",
            releaseDate: ele.published_at,
            aggregateRating: {
              ratingValue: '4.5',
              reviewCount: '10'
            },
            reviews: [{
              author: {
                type: 'Organization',
                name: 'Amada Middle East FZCO'
              },
              datePublished: ele.published_at,
              reviewBody: ele.description,
              name: ele.name,
              reviewRating: {
                bestRating: '5',
                ratingValue: '5',
                worstRating: '1'
              },
              publisher: {
                type: 'Organization',
                name: 'Amada Middle East FZCO'
              }
            }],
            offers: [{
              // priceCurrency: 'INR',
              url: `https://www.amada.ae/${slug}/${ele.slug}`,
              availability: 'InStock',
              seller: {
                name: 'Amada Middle East FZCO'
              },
              priceValidUntil: formatDate(result)
            }],
            mpn: ele.name,
            sku: "Amada Middle East FZCO"
          })
        });
      })]
    })
  });
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Category);
});

/***/ }),

/***/ 1790:
/***/ ((module) => {

module.exports = require("lozad");

/***/ }),

/***/ 2364:
/***/ ((module) => {

module.exports = require("next-seo");

/***/ }),

/***/ 9325:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 5378:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 7162:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 8773:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 2248:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 9372:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 665:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 2747:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 333:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 3456:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 7620:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 701:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6731:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 9297:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 3703:
/***/ ((module) => {

module.exports = import("react-markdown");;

/***/ }),

/***/ 5282:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [664,525], () => (__webpack_exec__(7208)));
module.exports = __webpack_exports__;

})();