exports.id = 525;
exports.ids = [525];
exports.modules = {

/***/ 6839:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Global_Layout)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./components/Global/SingleFlashNews.js




const SingleFlashNews = ({
  date,
  monthYear,
  flashNewsDetail,
  url
}) => {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "nf-item",
    children: [url == "" || url == "#" ? /*#__PURE__*/jsx_runtime_.jsx("a", {
      href: "javascript:void(0)",
      className: "nf-link"
    }) : /*#__PURE__*/jsx_runtime_.jsx("a", {
      href: url,
      target: "_blank",
      className: "nf-link",
      rel: "noreferrer"
    }), /*#__PURE__*/jsx_runtime_.jsx("span", {
      className: "nf-shape"
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "nf-bullet",
      children: !date ? /*#__PURE__*/jsx_runtime_.jsx("span", {
        className: "nf-link-icon"
      }) : /*#__PURE__*/(0,jsx_runtime_.jsxs)("time", {
        className: "date",
        dateTime: "2021-07-20",
        children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "text-lg",
          children: date
        }), /*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "cm-line-break",
          children: monthYear === null || monthYear === void 0 ? void 0 : monthYear.split(" ")[0]
        }), /*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "cm-line-break",
          children: monthYear === null || monthYear === void 0 ? void 0 : monthYear.split(" ")[1]
        })]
      })
    }), /*#__PURE__*/jsx_runtime_.jsx("p", {
      className: "nf-text",
      children: flashNewsDetail
    })]
  });
};

/* harmony default export */ const Global_SingleFlashNews = (SingleFlashNews);
;// CONCATENATED MODULE: ./components/Global/FlashNewsPopup.js





const FlashNewsPopup = ({
  flashNewsList
}) => {
  const {
    0: showPopup,
    1: setShowPopop
  } = (0,external_react_.useState)(false);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: `bs-news-fly ${showPopup ? "active" : ""}`,
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "nf-head",
      children: /*#__PURE__*/jsx_runtime_.jsx("h3", {
        className: "nf-title",
        children: flashNewsList === null || flashNewsList === void 0 ? void 0 : flashNewsList.sectionTitle
      })
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "nf-body",
      children: /*#__PURE__*/jsx_runtime_.jsx("ul", {
        className: "list",
        children: flashNewsList && flashNewsList.flashNewsList && flashNewsList.flashNewsList.map((news, index) => {
          return /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
            className: "item",
            children: [/*#__PURE__*/jsx_runtime_.jsx(Global_SingleFlashNews, {
              date: news === null || news === void 0 ? void 0 : news.date,
              monthYear: news === null || news === void 0 ? void 0 : news.monthYear,
              flashNewsDetail: news === null || news === void 0 ? void 0 : news.flashNewsDetail,
              url: news === null || news === void 0 ? void 0 : news.url
            }), ";"]
          }, index);
        })
      })
    }), /*#__PURE__*/jsx_runtime_.jsx("button", {
      className: "nf-trigger js-news-fly-trigger",
      type: "button",
      onClick: () => setShowPopop(!showPopup),
      children: /*#__PURE__*/jsx_runtime_.jsx("span", {
        className: "icon icon-file"
      })
    })]
  });
};

/* harmony default export */ const Global_FlashNewsPopup = (FlashNewsPopup);
// EXTERNAL MODULE: external "lozad"
var external_lozad_ = __webpack_require__(1790);
var external_lozad_default = /*#__PURE__*/__webpack_require__.n(external_lozad_);
// EXTERNAL MODULE: external "next-seo"
var external_next_seo_ = __webpack_require__(2364);
;// CONCATENATED MODULE: ./components/Global/Footer.js
/* eslint-disable @next/next/no-img-element */






const {
  REACT_APP_BASE_URL
} = process.env;

function Footer({
  footer,
  flashNews
}) {
  var _footer$socialMediaLi, _flashNews$flashNewsL, _footer$socialMediaLi2, _footer$socialMediaLi3;

  // console.log(footer)
  const {
    0: openSubMenu,
    1: setOpenSubMenu
  } = (0,external_react_.useState)(false);
  const {
    0: subMenuName,
    1: setSubMenuName
  } = (0,external_react_.useState)("");
  (0,external_react_.useEffect)(() => {
    const {
      observe
    } = external_lozad_default()();
    observe();
  }, []);
  const footerNav = footer.footerMenu;
  const social = footer.socialMediaLinks;

  const handleSubMenus = event => {
    setSubMenuName(event);
    setOpenSubMenu(!openSubMenu);

    if (openSubMenu === true && event !== subMenuName) {
      setOpenSubMenu(true);
    }
  }; /////////////////////////////////////////////////


  function chunkArray(myArray, chunk_size) {
    // console.log(myArray, 'myarray')
    let index = 0;
    let arrayLength = myArray !== undefined ? myArray.length : null;
    let tempArray = []; // console.log(arrayLength, 'array length')

    for (index = 0; index < arrayLength; index += chunk_size) {
      let myChunk = myArray.slice(index, index + chunk_size); // Do something if you want with the group

      tempArray.push(myChunk);
    }

    return tempArray;
  } // Split in group of 5 items


  let result = chunkArray(footer && footer.footerMenu, 6);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "bs-footer",
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "container",
        children: [result.slice(0, 1).map((items, index) => {
          // console.log(result, items, 'newitem')
          return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("ul", {
              className: "quicklink-item-wrap",
              children: [items.slice(0, 1).map((item, index) => {
                return /*#__PURE__*/jsx_runtime_.jsx("li", {
                  className: "quicklink-item",
                  children: /*#__PURE__*/jsx_runtime_.jsx("div", {
                    className: "mod-quicklink",
                    onClick: () => handleSubMenus(item.menuName),
                    children: /*#__PURE__*/jsx_runtime_.jsx("ul", {
                      className: `wrap ${subMenuName == item.footerSubmenu[0].subMenu && open ? "footer-sub-menu-open" : ""}`,
                      children: item.footerSubmenu && item.footerSubmenu.map((ele, index) => {
                        return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                          children: /*#__PURE__*/jsx_runtime_.jsx("li", {
                            className: "item",
                            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
                              className: "title",
                              href: ele.url === "#" || ele.url === "" || ele.url === "/" ? "javascript:void(0)" : ele.url,
                              target: `${ele.url && ele.url.includes("http") ? '_blank' : '_self'}`,
                              children: [" ", ele.subMenu]
                            })
                          }, index)
                        });
                      })
                    })
                  })
                }, index);
              }), items.slice(1).map((item, index) => {
                // console.log("item snehal==================", item)
                return /*#__PURE__*/jsx_runtime_.jsx("li", {
                  className: "quicklink-item",
                  children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                    className: "mod-quicklink",
                    onClick: () => handleSubMenus(item.menuName),
                    children: [/*#__PURE__*/jsx_runtime_.jsx("h2", {
                      className: `title mb-accord-title ${subMenuName === item.menuName && open ? "open" : ""}`,
                      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
                        href: item.url === "#" || item.url === "" ? "javascript:void(0)" : item.url,
                        target: `${item.url && item.url.includes("http") ? '_blank' : '_self'}`,
                        children: [" ", item.menuName]
                      })
                    }), /*#__PURE__*/jsx_runtime_.jsx("ul", {
                      className: `wrap mb-accord-body ${subMenuName == item.menuName && openSubMenu ? "footer-sub-menu-open" : ""}`,
                      children: item.footerSubmenu && item.footerSubmenu.map((ele, index) => {
                        return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                          children: /*#__PURE__*/jsx_runtime_.jsx("li", {
                            className: "item",
                            children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                              href: ele.url === "#" || ele.url === "" ? "javascript:void(0)" : ele.url,
                              target: `${ele.url && ele.url.includes("http") ? '_blank' : '_self'}`,
                              className: "link no-uppercase",
                              children: ele.subMenu
                            })
                          }, index)
                        });
                      })
                    })]
                  })
                }, index);
              })]
            })
          });
        }), result.slice(1).map((items, index) => {
          // console.log(result, items, 'newitem')
          return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
            children: /*#__PURE__*/jsx_runtime_.jsx("ul", {
              className: "quicklink-item-wrap",
              children: items.map((item, index) => {
                // console.log("item snehal==================", item)
                return /*#__PURE__*/jsx_runtime_.jsx("li", {
                  className: "quicklink-item",
                  children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                    className: "mod-quicklink",
                    onClick: () => handleSubMenus(item.menuName),
                    children: [/*#__PURE__*/jsx_runtime_.jsx("h2", {
                      className: `title mb-accord-title ${subMenuName === item.menuName && open ? "open" : ""}`,
                      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
                        href: item.url === "#" || item.url === "" ? "javascript:void(0)" : item.url,
                        target: `${item.url && item.url.includes("http") ? '_blank' : '_self'}`,
                        children: [" ", item.menuName]
                      })
                    }), /*#__PURE__*/jsx_runtime_.jsx("ul", {
                      className: `wrap mb-accord-body ${subMenuName == item.menuName && open ? "footer-sub-menu-open" : ""}`,
                      children: item.footerSubmenu && item.footerSubmenu.map((ele, index) => {
                        return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                          children: /*#__PURE__*/jsx_runtime_.jsx("li", {
                            className: "item",
                            children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                              href: ele.url === "#" || ele.url === "" ? "javascript:void(0)" : ele.url,
                              target: `${ele.url && ele.url.includes("http") ? '_blank' : '_self'}`,
                              className: "link no-uppercase",
                              children: ele.subMenu
                            })
                          }, index)
                        });
                      })
                    })]
                  })
                }, index);
              })
            })
          });
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "copy-wright",
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "mod-social-links",
            children: footer === null || footer === void 0 ? void 0 : (_footer$socialMediaLi = footer.socialMediaLinks) === null || _footer$socialMediaLi === void 0 ? void 0 : _footer$socialMediaLi.map((ele, i) => {
              var _ele$socialMediaLogo;

              return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                  target: "_blank",
                  href: ele.link,
                  className: "icon icon-youtube",
                  rel: "noreferrer",
                  children: /*#__PURE__*/jsx_runtime_.jsx("img", {
                    src: `${REACT_APP_BASE_URL}${(_ele$socialMediaLogo = ele.socialMediaLogo) === null || _ele$socialMediaLogo === void 0 ? void 0 : _ele$socialMediaLogo.url}`,
                    alt: ele.link
                  })
                }, i)
              });
            })
          }), /*#__PURE__*/jsx_runtime_.jsx("p", {
            children: "\xA9 Copyright, Amada Middle East FZCO, All Rights Reserved."
          })]
        })]
      })
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "bs-news-fly",
      children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "nf-head",
        children: /*#__PURE__*/jsx_runtime_.jsx("h3", {
          className: "nf-title",
          children: "flash news"
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "nf-body",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("ul", {
          className: "list",
          children: [/*#__PURE__*/jsx_runtime_.jsx("li", {
            className: "item",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "nf-item",
              children: [/*#__PURE__*/jsx_runtime_.jsx("a", {
                href: "#",
                className: "nf-link"
              }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                className: "nf-shape"
              }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "nf-bullet",
                children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("time", {
                  className: "date",
                  children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
                    className: "text-lg",
                    children: "20"
                  }), "jul 2021"]
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                className: "nf-text",
                children: "AMS Single Pallet Automation Webinar - LATC"
              })]
            })
          }), /*#__PURE__*/jsx_runtime_.jsx("li", {
            className: "item",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "nf-item",
              children: [/*#__PURE__*/jsx_runtime_.jsx("a", {
                href: "#",
                className: "nf-link"
              }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                className: "nf-shape"
              }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "nf-bullet"
              }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                className: "nf-text",
                children: "AMS Single Pallet Automation Webinar - CTC"
              })]
            })
          }), /*#__PURE__*/jsx_runtime_.jsx("li", {
            className: "item",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "nf-item",
              children: [/*#__PURE__*/jsx_runtime_.jsx("a", {
                href: "#",
                className: "nf-link"
              }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                className: "nf-shape"
              }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "nf-bullet"
              }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                className: "nf-text",
                children: "AMS Single Pallet Automation Webinar - SSC"
              })]
            })
          })]
        })
      }), (flashNews === null || flashNews === void 0 ? void 0 : (_flashNews$flashNewsL = flashNews.flashNewsList) === null || _flashNews$flashNewsL === void 0 ? void 0 : _flashNews$flashNewsL.length) > 0 && /*#__PURE__*/jsx_runtime_.jsx("button", {
        className: "nf-trigger js-news-fly-trigger",
        type: "button",
        children: /*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "icon icon-file"
        })
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx(external_next_seo_.SocialProfileJsonLd, {
      type: "Organization",
      name: "AMADA MIDDLE EAST FZCO",
      url: "https://www.amada.ae/",
      sameAs: [`${footer.socialMediaLinks && ((_footer$socialMediaLi2 = footer.socialMediaLinks[0]) === null || _footer$socialMediaLi2 === void 0 ? void 0 : _footer$socialMediaLi2.url)}`, `${footer.socialMediaLinks && ((_footer$socialMediaLi3 = footer.socialMediaLinks[1]) === null || _footer$socialMediaLi3 === void 0 ? void 0 : _footer$socialMediaLi3.url)}`]
    })]
  });
}

/* harmony default export */ const Global_Footer = (Footer);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
;// CONCATENATED MODULE: ./components/Global/Header.js
/* eslint-disable jsx-a11y/alt-text */

/* eslint-disable @next/next/no-img-element */







const {
  REACT_APP_BASE_URL: Header_REACT_APP_BASE_URL
} = process.env;

function Header({
  header,
  activeLink
}) {
  var _header$socialMediaLi, _header$socialMediaLi2;

  const {
    0: openMenus,
    1: setOpenMenus
  } = (0,external_react_.useState)(false);
  const {
    0: menuName,
    1: setMenuName
  } = (0,external_react_.useState)("");
  const {
    0: openNavbarMenus,
    1: setOpenNavbarMenus
  } = (0,external_react_.useState)(false);
  const {
    0: openSubMenu,
    1: setOpenSubMenu
  } = (0,external_react_.useState)(false);
  const {
    0: subMenuName,
    1: setSubMenuName
  } = (0,external_react_.useState)("");
  (0,external_react_.useEffect)(() => {
    const {
      observe
    } = external_lozad_default()();
    observe();
  }, []);

  const handleMenus = value => {
    if (window.innerWidth < 768) {
      setMenuName(value);
      setOpenMenus(!openMenus);

      if (openMenus === true && value !== menuName) {
        setOpenMenus(true);
      }
    }
  };

  const handleSubMenus = event => {
    if (window.innerWidth < 768) {
      setSubMenuName(event);
      setOpenSubMenu(!openSubMenu);

      if (openSubMenu === true && event !== subMenuName) {
        setOpenSubMenu(true);
      }
    }
  };

  const {
    logo,
    menu,
    socialMediaLinks
  } = header && header;

  function chunkArray(myArray, chunk_size) {
    // console.log(myArray, 'myarray')
    let index = 0;
    let arrayLength = myArray !== undefined ? myArray.length : null;
    let tempArray = []; // console.log(arrayLength, 'array length')

    for (index = 0; index < arrayLength; index += chunk_size) {
      let myChunk = myArray.slice(index, index + chunk_size); // Do something if you want with the group

      tempArray.push(myChunk);
    }

    return tempArray;
  } // let result = chunkArray(header && header.menu, 4)


  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "bs-header typ-solid",
    children: [logo ? /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
      href: "/",
      children: /*#__PURE__*/jsx_runtime_.jsx("a", {
        className: "logo-wrap",
        children: /*#__PURE__*/jsx_runtime_.jsx("img", {
          src: `${Header_REACT_APP_BASE_URL}${logo.url}`,
          alt: "Company Logo",
          title: "Amada Company Logo"
        })
      })
    }) : /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
      href: "/",
      children: /*#__PURE__*/jsx_runtime_.jsx("a", {
        className: "logo-wrap",
        children: /*#__PURE__*/jsx_runtime_.jsx("img", {
          src: "/assets/images/logo.png",
          alt: "Company Logo",
          title: "Amada Company Logo"
        })
      })
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: `bs-nav ${openNavbarMenus ? "active" : ""}`,
      children: [/*#__PURE__*/jsx_runtime_.jsx("button", {
        className: "nav-btn btn-close js-nav-close",
        children: /*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "icon icon-close",
          onClick: () => setOpenNavbarMenus(false)
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("ul", {
        className: "nav-list",
        children: menu === null || menu === void 0 ? void 0 : menu.map((ele, index) => {
          var _ele$subMenu$, _ele$subMenu$$subMenu, _ele$subMenu$2, _ele$subMenu$2$subMen, _ele$subMenu$3, _ele$subMenu$3$subMen;

          return /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
            className: `nav-item ${(ele === null || ele === void 0 ? void 0 : ele.subMenu.length) > 0 ? "bs-sub-menu " : ""} 
              ${(ele === null || ele === void 0 ? void 0 : (_ele$subMenu$ = ele.subMenu[0]) === null || _ele$subMenu$ === void 0 ? void 0 : (_ele$subMenu$$subMenu = _ele$subMenu$.subMenuLink) === null || _ele$subMenu$$subMenu === void 0 ? void 0 : _ele$subMenu$$subMenu.length) > 0 ? "typ-mega-menu" : ""}
              ${activeLink === (ele === null || ele === void 0 ? void 0 : ele.menuName) ? "active" : ""}`,
            children: [(ele === null || ele === void 0 ? void 0 : ele.subMenu.length) > 0 ? /*#__PURE__*/jsx_runtime_.jsx("a", {
              href: "javascript:void(0)",
              className: `nav-link mb-sub-menu-title ${openMenus && menuName === (ele === null || ele === void 0 ? void 0 : ele.menuName) ? "open" : ""}`,
              onClick: () => handleMenus(ele === null || ele === void 0 ? void 0 : ele.menuName),
              children: ele === null || ele === void 0 ? void 0 : ele.menuName
            }) : /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
              href: ele === null || ele === void 0 ? void 0 : ele.URL,
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                className: `nav-link`,
                children: ele === null || ele === void 0 ? void 0 : ele.menuName
              })
            }), (ele === null || ele === void 0 ? void 0 : ele.subMenu) && (ele === null || ele === void 0 ? void 0 : (_ele$subMenu$2 = ele.subMenu[0]) === null || _ele$subMenu$2 === void 0 ? void 0 : (_ele$subMenu$2$subMen = _ele$subMenu$2.subMenuLink) === null || _ele$subMenu$2$subMen === void 0 ? void 0 : _ele$subMenu$2$subMen.length) === 0 && /*#__PURE__*/jsx_runtime_.jsx("div", {
              className: `menu-wrap mb-sub-menu-body ${openMenus && menuName === (ele === null || ele === void 0 ? void 0 : ele.menuName) ? "sub-menu-open" : ""}
                  `,
              children: /*#__PURE__*/jsx_runtime_.jsx("ul", {
                className: "quicklink-item-wrap top",
                children: /*#__PURE__*/jsx_runtime_.jsx("li", {
                  className: "quicklink-item",
                  children: /*#__PURE__*/jsx_runtime_.jsx("div", {
                    className: "mod-quicklink mb-accord-body",
                    children: /*#__PURE__*/jsx_runtime_.jsx("ul", {
                      className: "wrap",
                      children: ele === null || ele === void 0 ? void 0 : ele.subMenu.map((elm, ind) => /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
                        className: "item",
                        children: [/*#__PURE__*/jsx_runtime_.jsx("a", {
                          href: elm.URL,
                          className: `title`,
                          target: `${elm.URL && elm.URL.includes("http") ? "_blank" : "_self"}`,
                          children: elm.subMenu
                        }), elm.subMenuLink && /*#__PURE__*/jsx_runtime_.jsx("ul", {
                          className: "wrap mb-accord-body",
                          children: elm.subMenuLink.map((el, i) => /*#__PURE__*/jsx_runtime_.jsx("li", {
                            className: "item",
                            children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                              href: el.URL,
                              className: "link",
                              children: el.subMenuLink
                            })
                          }, i))
                        })]
                      }, ind))
                    })
                  })
                })
              })
            }), (ele === null || ele === void 0 ? void 0 : ele.subMenu) && (ele === null || ele === void 0 ? void 0 : (_ele$subMenu$3 = ele.subMenu[0]) === null || _ele$subMenu$3 === void 0 ? void 0 : (_ele$subMenu$3$subMen = _ele$subMenu$3.subMenuLink) === null || _ele$subMenu$3$subMen === void 0 ? void 0 : _ele$subMenu$3$subMen.length) > 0 && /*#__PURE__*/jsx_runtime_.jsx("div", {
              className: `menu-wrap mb-sub-menu-body ${openMenus && menuName === (ele === null || ele === void 0 ? void 0 : ele.menuName) ? "sub-menu-open" : ""}`,
              children: chunkArray(ele && ele.subMenu, 4).map((ql, i) => {
                // console.log("ql",  ql)
                return /*#__PURE__*/jsx_runtime_.jsx("ul", {
                  className: "quicklink-item-wrap top",
                  children: ql.map((ell, inn) => {
                    return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                      children: /*#__PURE__*/jsx_runtime_.jsx("li", {
                        className: "quicklink-item",
                        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                          className: "mod-quicklink",
                          onClick: () => handleSubMenus(ell === null || ell === void 0 ? void 0 : ell.subMenu),
                          children: [/*#__PURE__*/jsx_runtime_.jsx("h2", {
                            className: `title mb-accord-title ${subMenuName == (ell === null || ell === void 0 ? void 0 : ell.subMenu) && openSubMenu ? "open" : ""}`,
                            children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                              href: ell === null || ell === void 0 ? void 0 : ell.URL,
                              children: ell === null || ell === void 0 ? void 0 : ell.subMenu
                            })
                          }), /*#__PURE__*/jsx_runtime_.jsx("ul", {
                            className: "wrap mb-accord-body",
                            style: window.innerWidth < 768 ? {
                              display: subMenuName == (ell === null || ell === void 0 ? void 0 : ell.subMenu) && openSubMenu ? "block" : "none"
                            } : null,
                            children: ell === null || ell === void 0 ? void 0 : ell.subMenuLink.map((sub, i) => /*#__PURE__*/jsx_runtime_.jsx("li", {
                              className: "item",
                              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                                href: sub.URL,
                                target: `${sub.URL && sub.URL.includes("http") ? '_blank' : '_self'}`,
                                className: "link no-uppercase",
                                children: sub.subMenuLink
                              })
                            }, i))
                          })]
                        })
                      }, inn)
                    });
                  })
                }, i);
              })
            })]
          }, index);
        })
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "bs-side-nav",
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("ul", {
        className: "nav-list",
        children: [/*#__PURE__*/jsx_runtime_.jsx("li", {
          className: "nav-item hidden-xs",
          children: /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "mod-social-links",
            children: socialMediaLinks === null || socialMediaLinks === void 0 ? void 0 : socialMediaLinks.map((ele, index) => {
              var _ele$socialMediaLogo;

              return /*#__PURE__*/jsx_runtime_.jsx("a", {
                href: ele === null || ele === void 0 ? void 0 : ele.link,
                target: `${ele !== null && ele !== void 0 && ele.link && ele !== null && ele !== void 0 && ele.link.includes("http") ? "_blank" : "_self"}`,
                className: "icon icon-youtube",
                children: /*#__PURE__*/jsx_runtime_.jsx("img", {
                  src: `${"https://strapi.amada.ae"}${ele === null || ele === void 0 ? void 0 : (_ele$socialMediaLogo = ele.socialMediaLogo) === null || _ele$socialMediaLogo === void 0 ? void 0 : _ele$socialMediaLogo.url}`
                })
              }, index);
            })
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("li", {
          className: "nav-item",
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
            href: "https://www.amada.com/",
            target: "_blank",
            className: "nav-link",
            rel: "noreferrer",
            children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "text",
              children: "ae"
            }), /*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "icon icon-globe"
            })]
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("li", {
          className: "nav-item",
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "menu-btn js-menu-open",
            onClick: () => setOpenNavbarMenus(true),
            children: [/*#__PURE__*/jsx_runtime_.jsx("span", {}), /*#__PURE__*/jsx_runtime_.jsx("span", {}), /*#__PURE__*/jsx_runtime_.jsx("span", {})]
          })
        })]
      })
    }), /*#__PURE__*/jsx_runtime_.jsx(external_next_seo_.SocialProfileJsonLd, {
      type: "Organization",
      name: "AMADA MIDDLE EAST FZCO",
      url: "https://www.amada.ae/",
      sameAs: [`${header.socialMediaLinks && ((_header$socialMediaLi = header.socialMediaLinks[0]) === null || _header$socialMediaLi === void 0 ? void 0 : _header$socialMediaLi.link)}`, `${header.socialMediaLinks && ((_header$socialMediaLi2 = header.socialMediaLinks[1]) === null || _header$socialMediaLi2 === void 0 ? void 0 : _header$socialMediaLi2.link)}`]
    }), /*#__PURE__*/jsx_runtime_.jsx(external_next_seo_.LogoJsonLd, {
      logo: "https://www.amada.ae/assets/images/logo.png",
      url: "https://www.amada.ae/"
    })]
  });
}

/* harmony default export */ const Global_Header = (Header);
;// CONCATENATED MODULE: ./components/Global/Layout.js






const {
  REACT_APP_BASE_URL: Layout_REACT_APP_BASE_URL
} = process.env;

function Layout({
  children,
  activeLink
}) {
  var _flashNews$flashNewsL;

  const {
    0: header,
    1: setHeader
  } = (0,external_react_.useState)([]);
  const {
    0: footer,
    1: setFooter
  } = (0,external_react_.useState)([]);
  const {
    0: flashNews,
    1: setFlashNews
  } = (0,external_react_.useState)([]);
  (0,external_react_.useEffect)(() => {
    const global = `${Layout_REACT_APP_BASE_URL}/global`;

    const fetchData = async () => {
      try {
        const res = await fetch(global);
        const json = await res.json(); // console.log(json, "full header");

        setHeader(json === null || json === void 0 ? void 0 : json.header);
        setFooter(json === null || json === void 0 ? void 0 : json.footer); // console.log(json.flashNewsSection.flashNewsList.length)

        setFlashNews(json === null || json === void 0 ? void 0 : json.flashNewsSection);
      } catch (error) {
        console.error(error);
      }
    };

    fetchData();
  }, []);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    children: [/*#__PURE__*/jsx_runtime_.jsx(Global_Header, {
      header: header,
      activeLink: activeLink
    }), children, /*#__PURE__*/jsx_runtime_.jsx(Global_Footer, {
      footer: footer,
      headerMenu: header,
      activeLink: activeLink,
      flashNews: flashNews
    }), (flashNews === null || flashNews === void 0 ? void 0 : (_flashNews$flashNewsL = flashNews.flashNewsList) === null || _flashNews$flashNewsL === void 0 ? void 0 : _flashNews$flashNewsL.length) > 0 && /*#__PURE__*/jsx_runtime_.jsx(Global_FlashNewsPopup, {
      flashNewsList: flashNews
    })]
  });
}

/* harmony default export */ const Global_Layout = (Layout);

/***/ }),

/***/ 2431:
/***/ (() => {

/* (ignored) */

/***/ })

};
;