"use strict";
(() => {
var exports = {};
exports.id = 669;
exports.ids = [669];
exports.modules = {

/***/ 8429:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ news_events),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "next-seo"
var external_next_seo_ = __webpack_require__(2364);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(701);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./components/Global/Layout.js + 4 modules
var Layout = __webpack_require__(6839);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./components/News Listing/Banner.js



const {
  REACT_APP_BASE_URL
} = process.env;

function Banner({
  event
}) {
  var _event$bannerImage;

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "bs-banner typ-sm lozad-background lozad",
    "data-background-image": `${REACT_APP_BASE_URL}${event === null || event === void 0 ? void 0 : (_event$bannerImage = event.bannerImage) === null || _event$bannerImage === void 0 ? void 0 : _event$bannerImage.url}`,
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "banner-title-wrap",
      children: /*#__PURE__*/jsx_runtime_.jsx("h2", {
        className: "banner-title",
        children: event === null || event === void 0 ? void 0 : event.bannerTitle
      })
    }), /*#__PURE__*/jsx_runtime_.jsx("span", {
      className: "corner-shape"
    })]
  });
}

/* harmony default export */ const News_Listing_Banner = (Banner);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
;// CONCATENATED MODULE: ./components/News Listing/Breadcrum.js






function Breadcrum({
  event
}) {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "bs-breadcrum",
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "container",
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("ul", {
        className: "list",
        children: [/*#__PURE__*/jsx_runtime_.jsx("li", {
          className: "item",
          children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
            href: "/",
            children: /*#__PURE__*/jsx_runtime_.jsx("a", {
              className: "link",
              children: "amada"
            })
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("li", {
          className: "item",
          children: event === null || event === void 0 ? void 0 : event.bannerTitle
        })]
      })
    }), /*#__PURE__*/jsx_runtime_.jsx(external_next_seo_.BreadcrumbJsonLd, {
      itemListElements: [{
        position: 1,
        name: 'amada',
        item: `https://www.amada.ae`
      }, {
        position: 2,
        name: event === null || event === void 0 ? void 0 : event.bannerTitle,
        item: `https://www.amada.ae/news-events`
      }]
    })]
  });
}

/* harmony default export */ const News_Listing_Breadcrum = (Breadcrum);
// EXTERNAL MODULE: external "lozad"
var external_lozad_ = __webpack_require__(1790);
var external_lozad_default = /*#__PURE__*/__webpack_require__.n(external_lozad_);
;// CONCATENATED MODULE: ./components/News Listing/NewsCards.js
/* eslint-disable @next/next/link-passhref */






const {
  REACT_APP_BASE_URL: NewsCards_REACT_APP_BASE_URL
} = process.env;

function NewsCards({
  event
}) {
  var _event$newsSection, _event$newsSection2;

  (0,external_react_.useEffect)(() => {
    const {
      observe
    } = external_lozad_default()();
    observe();
  }, []);
  var newSort = event.newsSection.news_events.sort((a, b) => a.date < b.date && 1 || -1);
  var linkedin = newSort.filter(el => el.isLinkedin);
  var notLinkedin = newSort.filter(el => !el.isLinkedin);
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    children: /*#__PURE__*/jsx_runtime_.jsx("section", {
      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "bs-section",
        children: /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "container",
          children: /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "sec-cont",
            children: /*#__PURE__*/jsx_runtime_.jsx("div", {
              className: "bs-event-card",
              children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("ul", {
                className: "list",
                children: [(event === null || event === void 0 ? void 0 : (_event$newsSection = event.newsSection) === null || _event$newsSection === void 0 ? void 0 : _event$newsSection.isActive) && (linkedin === null || linkedin === void 0 ? void 0 : linkedin.map((ele, index) => {
                  var _ele$smallImage, _ele$smallImage2;

                  return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                    children: ele.isLinkedin && ele.url && ((_ele$smallImage = ele.smallImage) === null || _ele$smallImage === void 0 ? void 0 : _ele$smallImage.url) && ele.title && /*#__PURE__*/jsx_runtime_.jsx("li", {
                      className: "item",
                      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
                        className: "bs-img-overlay",
                        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                          className: "img-wrap bs-news lozad-background lozad",
                          "data-background-image": `${NewsCards_REACT_APP_BASE_URL}${(_ele$smallImage2 = ele.smallImage) === null || _ele$smallImage2 === void 0 ? void 0 : _ele$smallImage2.url}`,
                          children: [/*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                            href: ele.url,
                            children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                              target: "_blank",
                              rel: "noreferrer",
                              className: "news-link"
                            })
                          }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                            className: "icon icon-linkedin"
                          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                            className: "news-info",
                            children: [ele.url && ele.date && /*#__PURE__*/(0,jsx_runtime_.jsxs)("time", {
                              className: "date",
                              children: [" ", `${new Date(ele.date).toLocaleString("default", {
                                month: "long"
                              })} 
                                    ${new Date(ele.date).toLocaleString("default", {
                                year: "numeric"
                              })}`]
                            }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                              className: "desc",
                              children: ele.title
                            })]
                          })]
                        })
                      })
                    }, index)
                  });
                })), (event === null || event === void 0 ? void 0 : (_event$newsSection2 = event.newsSection) === null || _event$newsSection2 === void 0 ? void 0 : _event$newsSection2.isActive) && (notLinkedin === null || notLinkedin === void 0 ? void 0 : notLinkedin.map((ele, index) => {
                  var _ele$smallImage3, _ele$smallImage4, _ele$gallery, _ele$pdfFile, _ele$pdfFile2;

                  return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                    children: !ele.isLinkedin && ((_ele$smallImage3 = ele.smallImage) === null || _ele$smallImage3 === void 0 ? void 0 : _ele$smallImage3.url) && ele.title && /*#__PURE__*/jsx_runtime_.jsx("li", {
                      className: "item",
                      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
                        className: "bs-img-overlay",
                        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                          className: "img-wrap bs-news lozad-background lozad",
                          "data-background-image": `${NewsCards_REACT_APP_BASE_URL}${(_ele$smallImage4 = ele.smallImage) === null || _ele$smallImage4 === void 0 ? void 0 : _ele$smallImage4.url}`,
                          children: [(ele === null || ele === void 0 ? void 0 : (_ele$gallery = ele.gallery) === null || _ele$gallery === void 0 ? void 0 : _ele$gallery.length) === 0 && ele !== null && ele !== void 0 && ele.pdfFile && ele !== null && ele !== void 0 && (_ele$pdfFile = ele.pdfFile) !== null && _ele$pdfFile !== void 0 && _ele$pdfFile.url ? /*#__PURE__*/jsx_runtime_.jsx("a", {
                            href: `${NewsCards_REACT_APP_BASE_URL}${ele === null || ele === void 0 ? void 0 : (_ele$pdfFile2 = ele.pdfFile) === null || _ele$pdfFile2 === void 0 ? void 0 : _ele$pdfFile2.url}`,
                            target: "_blank",
                            rel: "noreferrer",
                            className: "news-link"
                          }) : /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                            href: `/news-events/${ele === null || ele === void 0 ? void 0 : ele.slug}`,
                            children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                              className: "news-link"
                            })
                          }, index), /*#__PURE__*/jsx_runtime_.jsx("div", {
                            className: "news-info",
                            children: /*#__PURE__*/jsx_runtime_.jsx("p", {
                              className: "desc",
                              children: ele.title
                            })
                          })]
                        })
                      })
                    }, index)
                  });
                }))]
              })
            })
          })
        })
      })
    })
  });
}

/* harmony default export */ const News_Listing_NewsCards = (NewsCards);
;// CONCATENATED MODULE: ./pages/news-events/index.js
/* eslint-disable @next/next/link-passhref */










async function getServerSideProps() {
  const res = await fetch(`${"https://strapi.amada.ae"}/news-and-events-page`);
  const json = await res.json();
  return {
    props: {
      event: json
    }
  };
}

function NewsEvents({
  event
}) {
  var _event$newsSection, _event$newsSection$ne, _event$newsSection2, _event$newsSection3, _event$newsSection3$n;

  console.log('the events', event);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [event.seo !== null && /*#__PURE__*/jsx_runtime_.jsx(external_next_seo_.NextSeo, {
      title: event.seo.metaTitle,
      description: event.seo.metaDescription,
      keyword: event.seo.metaKeyword,
      noindex: event.seo.noIndex,
      nofollow: event.seo.noFollow
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)((head_default()), {
      children: [/*#__PURE__*/jsx_runtime_.jsx("title", {
        children: "NEWS & EVENTS"
      }), /*#__PURE__*/jsx_runtime_.jsx("link", {
        rel: "icon",
        href: "../static/favicon.ico"
      })]
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(Layout/* default */.Z, {
      activeLink: "News & Events",
      children: [/*#__PURE__*/jsx_runtime_.jsx("main", {
        children: /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "main lyt-content js-bg",
          children: event.bannerTitle || event.bannerImage ? /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
            children: [/*#__PURE__*/jsx_runtime_.jsx(News_Listing_Banner, {
              event: event
            }), /*#__PURE__*/jsx_runtime_.jsx(News_Listing_Breadcrum, {
              event: event
            }), (event === null || event === void 0 ? void 0 : (_event$newsSection = event.newsSection) === null || _event$newsSection === void 0 ? void 0 : (_event$newsSection$ne = _event$newsSection.news_events) === null || _event$newsSection$ne === void 0 ? void 0 : _event$newsSection$ne.length) > 0 && event !== null && event !== void 0 && (_event$newsSection2 = event.newsSection) !== null && _event$newsSection2 !== void 0 && _event$newsSection2.isActive ? /*#__PURE__*/jsx_runtime_.jsx(News_Listing_NewsCards, {
              event: event
            }) : /*#__PURE__*/jsx_runtime_.jsx("div", {
              className: "mod-greeting",
              children: /*#__PURE__*/jsx_runtime_.jsx("h1", {
                className: "title",
                children: "Coming soon"
              })
            })]
          }) : /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "mod-greeting",
            children: /*#__PURE__*/jsx_runtime_.jsx("h1", {
              className: "title",
              children: "Coming soon"
            })
          })
        })
      }), event === null || event === void 0 ? void 0 : (_event$newsSection3 = event.newsSection) === null || _event$newsSection3 === void 0 ? void 0 : (_event$newsSection3$n = _event$newsSection3.news_events) === null || _event$newsSection3$n === void 0 ? void 0 : _event$newsSection3$n.map((ele, i) => {
        return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
          children: /*#__PURE__*/jsx_runtime_.jsx(external_next_seo_.NewsArticleJsonLd, {
            keyOverride: i,
            url: `https://www.amada.ae/news-events`,
            title: ele.title,
            images: [`${"https://strapi.amada.ae"}${ele.smallImage.url}`],
            section: "technology",
            datePublished: ele.published_at,
            dateModified: ele.updated_at,
            authorName: "Amada",
            publisherName: "Amada Bureau",
            publisherLogo: "https://www.amada.ae/assets/images/logo.png",
            body: ele.subtitle
          })
        });
      })]
    })]
  });
}

/* harmony default export */ const news_events = (NewsEvents);

/***/ }),

/***/ 1790:
/***/ ((module) => {

module.exports = require("lozad");

/***/ }),

/***/ 2364:
/***/ ((module) => {

module.exports = require("next-seo");

/***/ }),

/***/ 9325:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 5378:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 7162:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 8773:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 2248:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 9372:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 665:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 2747:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 333:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 3456:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 7620:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 701:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 9297:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 5282:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [664,525], () => (__webpack_exec__(8429)));
module.exports = __webpack_exports__;

})();