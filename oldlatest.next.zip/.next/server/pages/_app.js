"use strict";
(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 8217:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(701);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./context/context.js
var context = __webpack_require__(5747);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
;// CONCATENATED MODULE: external "react-hook-form"
const external_react_hook_form_namespaceObject = require("react-hook-form");
;// CONCATENATED MODULE: external "emailjs-com"
const external_emailjs_com_namespaceObject = require("emailjs-com");
// EXTERNAL MODULE: ./hooks/useGlobalContext.js
var useGlobalContext = __webpack_require__(3729);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./components/Product/DownloadBrochureForm/index.js
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }









function DownloadBrochureForm(props) {
  const {
    0: formData,
    1: setFormData
  } = (0,external_react_.useState)({});
  const {
    0: isEmailSent,
    1: setIsEmailSent
  } = (0,external_react_.useState)(false);
  const {
    register,
    handleSubmit,
    reset,
    formState: {
      errors
    }
  } = (0,external_react_hook_form_namespaceObject.useForm)();
  const {
    isModalOpen,
    setIsModalOpen,
    downloadBrochureUrl,
    setDownloadBrochureUrl,
    product,
    setProduct
  } = (0,useGlobalContext/* useGlobalContext */.b)();

  const onSubmit = data => {
    console.log(data);
    let emailForm = {
      customerName: data.fullName,
      email: data.email,
      contactNumber: "",
      companyName: data.companyName,
      city: "",
      state: "",
      address: data.addressType + '-' + data.address,
      machineOfInterest: "",
      materialThickness: "",
      country: "",
      comment: `This data was submitted while downloading ${product} brochure`
    };
    (0,external_emailjs_com_namespaceObject.send)('service_3bq8q4o', 'template_dpawpll', emailForm, 'CT_ov-ETHpvKfz4VV').then(response => {
      console.log('SUCCESS!', response.status, response.text);

      if (response.status == 200) {
        if (downloadBrochureUrl) {
          window.open(downloadBrochureUrl, {
            target: '_blank'
          }); // setIsEmailSent(true)

          setFormData({});
          reset();
          setDownloadBrochureUrl(null);
          setIsModalOpen(false);
          setProduct(null);
        }
      }
    }).catch(err => {
      console.log('FAILED...', err);
      setIsModalOpen(false);
    });
  };

  return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
    children: isModalOpen ? /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "popup-overlay",
      style: {
        background: "rgba(0,0,0,0.6)",
        position: "fixed",
        inset: 0,
        zIndex: 21
      },
      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "popup-card",
        children: /*#__PURE__*/jsx_runtime_.jsx("div", {
          children: /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "main js-bg",
            children: !isEmailSent ? /*#__PURE__*/jsx_runtime_.jsx("section", {
              children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                className: "container content",
                style: {
                  width: "100%"
                },
                children: [/*#__PURE__*/jsx_runtime_.jsx("h2", {
                  style: {
                    fontSize: "18px",
                    marginBottom: 15,
                    fontWeight: 500
                  },
                  children: "Fill Your Details"
                }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                  className: "sec-cont",
                  children: /*#__PURE__*/jsx_runtime_.jsx("form", {
                    className: "",
                    onSubmit: handleSubmit(onSubmit),
                    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                      className: "bs-form",
                      children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
                        className: "form-wrap",
                        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("ul", {
                          className: "row",
                          children: [/*#__PURE__*/jsx_runtime_.jsx("li", {
                            className: "col-md-6 col-xs-12",
                            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                              className: `form-group `,
                              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                                className: "field-label typ-req",
                                children: "Full Name"
                              }), /*#__PURE__*/jsx_runtime_.jsx("input", _objectSpread({
                                type: "text",
                                name: "fullName",
                                className: "form-control",
                                placeholder: "Enter Full Name",
                                onChange: e => setFormData(_objectSpread(_objectSpread({}, formData), {}, {
                                  fullName: e.target.value
                                })),
                                value: formData.fullName
                              }, register("fullName", {
                                required: true
                              }))), errors && errors.fullName && /*#__PURE__*/jsx_runtime_.jsx("div", {
                                children: errors.fullName && errors.fullName.type === "required" && /*#__PURE__*/jsx_runtime_.jsx("p", {
                                  className: "error-text",
                                  children: "Full name is Required !"
                                })
                              })]
                            })
                          }), /*#__PURE__*/jsx_runtime_.jsx("li", {
                            className: "col-md-6 col-xs-12",
                            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                              className: `form-group`,
                              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                                className: "field-label typ-req",
                                children: "Company Name"
                              }), /*#__PURE__*/jsx_runtime_.jsx("input", _objectSpread({
                                type: "text",
                                name: "company",
                                className: "form-control",
                                placeholder: "Enter Company Name",
                                value: formData.companyName,
                                onChange: e => setFormData(_objectSpread(_objectSpread({}, formData), {}, {
                                  companyName: e.target.value
                                }))
                              }, register("companyName", {
                                required: true
                              }))), errors && errors.companyName && /*#__PURE__*/jsx_runtime_.jsx("div", {
                                children: errors.companyName && errors.companyName.type === "required" && /*#__PURE__*/jsx_runtime_.jsx("p", {
                                  className: "error-text",
                                  children: "Company name is Required !"
                                })
                              })]
                            })
                          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
                            className: "col-md-6 col-xs-12",
                            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                              className: "field-label typ-req",
                              children: "Select Address type"
                            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                              className: `form-group radio-wrap`,
                              children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                                className: "bs-radio",
                                children: [/*#__PURE__*/jsx_runtime_.jsx("input", _objectSpread({
                                  type: "radio",
                                  id: "addressType1",
                                  maxLength: "10",
                                  name: "home",
                                  defaultChecked: true,
                                  value: "home",
                                  onChange: e => // setFormData({
                                  //   ...formData,
                                  //   addressType: e.target.value,
                                  // })
                                  console.log(e.target.value)
                                }, register("addressType", {
                                  required: true
                                }))), /*#__PURE__*/(0,jsx_runtime_.jsxs)("label", {
                                  htmlFor: "addressType1",
                                  children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
                                    className: "icon icon-radio-uncheck"
                                  }), " ", "Home"]
                                })]
                              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                                className: "bs-radio",
                                children: [/*#__PURE__*/jsx_runtime_.jsx("input", _objectSpread({
                                  type: "radio",
                                  id: "addressType2",
                                  maxLength: "10",
                                  name: "company",
                                  value: "company",
                                  onChange: e => setFormData(_objectSpread(_objectSpread({}, formData), {}, {
                                    addressType: e.target.value
                                  }))
                                }, register("addressType", {
                                  required: true
                                }))), /*#__PURE__*/(0,jsx_runtime_.jsxs)("label", {
                                  htmlFor: "addressType2",
                                  children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
                                    className: "icon icon-radio-uncheck"
                                  }), " ", "Company"]
                                })]
                              }), errors && errors.addressType && /*#__PURE__*/jsx_runtime_.jsx("div", {
                                children: errors.addressType && errors.addressType.type === "required" && /*#__PURE__*/jsx_runtime_.jsx("p", {
                                  className: "error-text",
                                  children: "Address type is Required !"
                                })
                              })]
                            })]
                          }), /*#__PURE__*/jsx_runtime_.jsx("li", {
                            className: "col-md-6 col-xs-12",
                            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                              className: `form-group`,
                              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                                className: "field-label typ-req",
                                children: "Address"
                              }), /*#__PURE__*/jsx_runtime_.jsx("input", _objectSpread({
                                type: "tel",
                                maxLength: "10",
                                name: "address",
                                className: "form-control",
                                placeholder: "Enter Address",
                                value: formData.address,
                                onChange: e => setFormData(_objectSpread(_objectSpread({}, formData), {}, {
                                  address: e.target.value
                                }))
                              }, register("address", {
                                required: true
                              }))), errors && errors.address && /*#__PURE__*/jsx_runtime_.jsx("div", {
                                children: errors.address && errors.address.type === "required" && /*#__PURE__*/jsx_runtime_.jsx("p", {
                                  className: "error-text",
                                  children: "Address is Required !"
                                })
                              })]
                            })
                          }), /*#__PURE__*/jsx_runtime_.jsx("li", {
                            className: "col-md-6 col-xs-12",
                            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                              className: "form-group",
                              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                                className: "field-label typ-req",
                                children: "Country"
                              }), /*#__PURE__*/jsx_runtime_.jsx("input", _objectSpread({
                                type: "text",
                                name: "country",
                                className: "form-control",
                                placeholder: "Enter Country",
                                value: formData.country,
                                onChange: e => setFormData(_objectSpread(_objectSpread({}, formData), {}, {
                                  country: e.target.value
                                }))
                              }, register("country", {
                                required: true
                              }))), errors && errors.country && /*#__PURE__*/jsx_runtime_.jsx("div", {
                                children: errors.country && errors.country.type === "required" && /*#__PURE__*/jsx_runtime_.jsx("p", {
                                  className: "error-text",
                                  children: "Country is Required !"
                                })
                              })]
                            })
                          }), /*#__PURE__*/jsx_runtime_.jsx("li", {
                            className: "col-md-6 col-xs-12",
                            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                              className: `form-group`,
                              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                                className: "field-label typ-req",
                                children: "Phone Number"
                              }), /*#__PURE__*/jsx_runtime_.jsx("input", _objectSpread({
                                type: "text",
                                name: "phone",
                                className: "form-control",
                                placeholder: "Enter Phone Number",
                                value: formData.contactNumber,
                                onChange: e => setFormData(_objectSpread(_objectSpread({}, formData), {}, {
                                  contactNumber: e.target.value
                                }))
                              }, register("contactNumber", {
                                required: true,
                                pattern: /^\d{10}$/,
                                maxLength: 10,
                                minLength: 10
                              }))), errors && errors.contactNumber && /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                                children: [errors.contactNumber && errors.contactNumber.type === "required" && /*#__PURE__*/jsx_runtime_.jsx("p", {
                                  className: "error-text",
                                  children: "Phone Number is Required !"
                                }), errors.contactNumber && errors.contactNumber.type === "maxLength" && /*#__PURE__*/jsx_runtime_.jsx("p", {
                                  className: "error-text",
                                  children: "The Phone Number should be 10 digits only !"
                                }), errors.contactNumber && errors.contactNumber.type === "minLength" && /*#__PURE__*/jsx_runtime_.jsx("p", {
                                  className: "error-text",
                                  children: "The Phone Number should be 10 digits !"
                                }), errors.contactNumber && errors.contactNumber.type === "pattern" && /*#__PURE__*/jsx_runtime_.jsx("p", {
                                  className: "error-text",
                                  children: "The Phone Number should be Integers !"
                                })]
                              })]
                            })
                          }), /*#__PURE__*/jsx_runtime_.jsx("li", {
                            className: "col-md-6 col-xs-12",
                            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                              className: `form-group`,
                              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                                className: "field-label typ-req",
                                children: "Email"
                              }), /*#__PURE__*/jsx_runtime_.jsx("input", _objectSpread({
                                type: "text",
                                name: "email",
                                className: "form-control",
                                placeholder: "Enter Email",
                                value: formData.email,
                                onChange: e => setFormData(_objectSpread(_objectSpread({}, formData), {}, {
                                  email: e.target.value
                                }))
                              }, register("email", {
                                required: true,
                                pattern: /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/
                              }))), errors && errors.email && /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                                children: [errors.email && errors.email.type === "required" && /*#__PURE__*/jsx_runtime_.jsx("p", {
                                  className: "error-text",
                                  children: "Email is Required !"
                                }), errors.email && errors.email.type === "pattern" && /*#__PURE__*/jsx_runtime_.jsx("p", {
                                  className: "error-text",
                                  children: "The Email is Invalid !"
                                })]
                              })]
                            })
                          }), /*#__PURE__*/jsx_runtime_.jsx("li", {
                            className: "col-md-6 col-xs-12",
                            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                              className: `form-group`,
                              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                                className: "field-label typ-req",
                                children: "Interested Product"
                              }), /*#__PURE__*/jsx_runtime_.jsx("input", _objectSpread({
                                type: "text",
                                name: "interestedProduct",
                                className: "form-control",
                                placeholder: "Enter Interested Product",
                                value: formData.interestedProduct,
                                onChange: e => setFormData(_objectSpread(_objectSpread({}, formData), {}, {
                                  interestedProduct: e.target.value
                                }))
                              }, register("interestedProduct", {
                                required: true
                              }))), errors && errors.interestedProduct && /*#__PURE__*/jsx_runtime_.jsx("div", {
                                children: errors.interestedProduct && errors.interestedProduct.type === "required" && /*#__PURE__*/jsx_runtime_.jsx("p", {
                                  className: "error-text",
                                  children: "Please enter your interested product !"
                                })
                              })]
                            })
                          })]
                        })
                      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                        className: "form-action",
                        children: [/*#__PURE__*/jsx_runtime_.jsx("button", {
                          type: "submit",
                          className: "bs-btn btn-default",
                          children: "submit"
                        }), /*#__PURE__*/jsx_runtime_.jsx("button", {
                          type: "reset",
                          onClick: () => {
                            setIsModalOpen(false);
                            setProduct(null);
                            setDownloadBrochureUrl(null);
                          },
                          className: "bs-btn btn-icon-link",
                          children: "cancel"
                        })]
                      })]
                    })
                  })
                })]
              })
            }) : /*#__PURE__*/jsx_runtime_.jsx("section", {
              children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                className: "container content",
                style: {
                  width: "100%"
                },
                children: [/*#__PURE__*/jsx_runtime_.jsx("h4", {
                  style: {
                    fontSize: "18px",
                    marginBottom: 60,
                    marginTop: 60,
                    fontWeight: 500,
                    textAlign: "center"
                  },
                  children: "Brochure download url is sent to the given email id"
                }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                  className: "sec-cont",
                  style: {
                    textAlign: "center"
                  },
                  children: /*#__PURE__*/jsx_runtime_.jsx("div", {
                    className: "form-action",
                    children: /*#__PURE__*/jsx_runtime_.jsx("button", {
                      type: "submit",
                      onClick: () => {
                        setIsModalOpen(false);
                        setIsEmailSent(false);
                      },
                      className: "bs-btn btn-default",
                      children: "OK"
                    })
                  })
                })]
              })
            })
          })
        })
      })
    }) : null
  });
}

/* harmony default export */ const Product_DownloadBrochureForm = (DownloadBrochureForm);
;// CONCATENATED MODULE: ./pages/_app.js
function _app_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _app_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { _app_ownKeys(Object(source), true).forEach(function (key) { _app_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { _app_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _app_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }









const {
  NEXT_PUBLIC_GOOGLE_ANALYTICS
} = process.env;

function MyApp({
  Component,
  pageProps
}) {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)((head_default()), {
      children: [/*#__PURE__*/jsx_runtime_.jsx("meta", {
        name: "viewport",
        content: "width=device-width, initial-scale=1"
      }), /*#__PURE__*/jsx_runtime_.jsx("link", {
        rel: "icon",
        href: "./static/favicon.ico"
      }), /*#__PURE__*/jsx_runtime_.jsx("script", {
        async: true,
        src: "https://www.googletagmanager.com/gtag/js?id=G-NQ7F7XCH9J"
      }), /*#__PURE__*/jsx_runtime_.jsx("script", {
        dangerouslySetInnerHTML: {
          __html: `
              window.dataLayer = window.dataLayer || [];
              function gtag(){dataLayer.push(arguments);}
              gtag('js', new Date());
            
              gtag('config', 'G-NQ7F7XCH9J');
          `
        }
      })]
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(context/* default */.Z, {
      children: [/*#__PURE__*/jsx_runtime_.jsx(Component, _app_objectSpread({}, pageProps)), /*#__PURE__*/jsx_runtime_.jsx(Product_DownloadBrochureForm, {})]
    })]
  });
}

/* harmony default export */ const _app = (MyApp);

/***/ }),

/***/ 701:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 9297:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 5282:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [729], () => (__webpack_exec__(8217)));
module.exports = __webpack_exports__;

})();